﻿----------------------------------------------------
--------LOẠI MÓN------------------------------------
USE HuongViet
GO
INSERT INTO LOAIMON VALUES (1,N'Món nước')
INSERT INTO LOAIMON VALUES (2,N'Cơm')
INSERT INTO LOAIMON VALUES (3,N'Nem-chả')
INSERT INTO LOAIMON VALUES (4,N'Món gỏi')
INSERT INTO LOAIMON VALUES (5,N'Món Bánh Mặn')
INSERT INTO LOAIMON VALUES (6,N'Món Bánh ngọt')
INSERT INTO LOAIMON VALUES (7,N'Nước ép')
-----------------------------------------------------
-----------------------------------------------------
---------------món ăn--------------------------------
INSERT INTO MONAN VALUES (1,N'Bún',1,50000)
INSERT INTO MONAN VALUES (2,N'Phở',1,80000)
INSERT INTO MONAN VALUES (3,N'Cơm chiên hải sản',2,100000)
INSERT INTO MONAN VALUES (4,N'Chả cá basa',3,50000)
INSERT INTO MONAN VALUES (5,N'Chả lụa',3,50000)
INSERT INTO MONAN VALUES (6,N'Nem rán',3,50000)
INSERT INTO MONAN VALUES (7,N'Gỏi xoài',4,80000)
INSERT INTO MONAN VALUES (8,N'Gỏi ngó sen',4,100000)
INSERT INTO MONAN VALUES (9,N'Gỏi nộm sứa',4,200000)
INSERT INTO MONAN VALUES (10,N'Bánh xèo',5,50000)
INSERT INTO MONAN VALUES (11,N'Bánh muffin',6,99000)
INSERT INTO MONAN VALUES (12,N'Bánh PAVLOVA',6,99000)
INSERT INTO MONAN VALUES (13,N'Nước ép xoài',7,60000)
INSERT INTO MONAN VALUES (14,N'Nước ép cam',7,60000)
INSERT INTO MONAN VALUES (15,N'Nước ép dâu',7,60000)
INSERT INTO MONAN VALUES (16,N'Nước ép táo',7,60000)
