﻿namespace HuongVIet
{
    partial class ThongKeCongTy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ngay = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.thang = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.nam = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.mon = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.loaimon = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.loaikh = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.kenh = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.huytheokenh = new System.Windows.Forms.DataGridView();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.huytheoloai = new System.Windows.Forms.DataGridView();
            this.back = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ngay)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thang)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nam)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mon)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loaimon)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loaikh)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kenh)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.huytheokenh)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.huytheoloai)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(0, 34);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(850, 383);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ngay);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(842, 354);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ngày";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ngay
            // 
            this.ngay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ngay.Location = new System.Drawing.Point(3, 3);
            this.ngay.Name = "ngay";
            this.ngay.ReadOnly = true;
            this.ngay.RowTemplate.Height = 24;
            this.ngay.Size = new System.Drawing.Size(836, 348);
            this.ngay.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.thang);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(842, 354);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tháng";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // thang
            // 
            this.thang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.thang.Location = new System.Drawing.Point(3, 3);
            this.thang.Name = "thang";
            this.thang.ReadOnly = true;
            this.thang.RowTemplate.Height = 24;
            this.thang.Size = new System.Drawing.Size(836, 348);
            this.thang.TabIndex = 2;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.nam);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(842, 354);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Năm";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // nam
            // 
            this.nam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.nam.Location = new System.Drawing.Point(3, 3);
            this.nam.Name = "nam";
            this.nam.ReadOnly = true;
            this.nam.RowTemplate.Height = 24;
            this.nam.Size = new System.Drawing.Size(836, 348);
            this.nam.TabIndex = 2;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.mon);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(842, 354);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Món";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // mon
            // 
            this.mon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mon.Location = new System.Drawing.Point(3, 3);
            this.mon.Name = "mon";
            this.mon.ReadOnly = true;
            this.mon.RowTemplate.Height = 24;
            this.mon.Size = new System.Drawing.Size(836, 348);
            this.mon.TabIndex = 2;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.loaimon);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(842, 354);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Loại món";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // loaimon
            // 
            this.loaimon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.loaimon.Location = new System.Drawing.Point(3, 3);
            this.loaimon.Name = "loaimon";
            this.loaimon.ReadOnly = true;
            this.loaimon.RowTemplate.Height = 24;
            this.loaimon.Size = new System.Drawing.Size(836, 348);
            this.loaimon.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.loaikh);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(842, 354);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Loại khách hàng";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // loaikh
            // 
            this.loaikh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.loaikh.Location = new System.Drawing.Point(3, 3);
            this.loaikh.Name = "loaikh";
            this.loaikh.ReadOnly = true;
            this.loaikh.RowTemplate.Height = 24;
            this.loaikh.Size = new System.Drawing.Size(836, 348);
            this.loaikh.TabIndex = 2;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.kenh);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(842, 354);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Kênh đặt hàng";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // kenh
            // 
            this.kenh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kenh.Location = new System.Drawing.Point(3, 3);
            this.kenh.Name = "kenh";
            this.kenh.ReadOnly = true;
            this.kenh.RowTemplate.Height = 24;
            this.kenh.Size = new System.Drawing.Size(836, 348);
            this.kenh.TabIndex = 2;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.huytheokenh);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(842, 354);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Hủy đơn theo kênh đặt hàng";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // huytheokenh
            // 
            this.huytheokenh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.huytheokenh.Location = new System.Drawing.Point(3, 3);
            this.huytheokenh.Name = "huytheokenh";
            this.huytheokenh.ReadOnly = true;
            this.huytheokenh.RowTemplate.Height = 24;
            this.huytheokenh.Size = new System.Drawing.Size(836, 348);
            this.huytheokenh.TabIndex = 2;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.huytheoloai);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(842, 354);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Hủy đơn theo loại khách hàng";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // huytheoloai
            // 
            this.huytheoloai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.huytheoloai.Location = new System.Drawing.Point(3, 3);
            this.huytheoloai.Name = "huytheoloai";
            this.huytheoloai.ReadOnly = true;
            this.huytheoloai.RowTemplate.Height = 24;
            this.huytheoloai.Size = new System.Drawing.Size(836, 348);
            this.huytheoloai.TabIndex = 2;
            // 
            // back
            // 
            this.back.AutoSize = true;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.Location = new System.Drawing.Point(0, -2);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(95, 20);
            this.back.TabIndex = 24;
            this.back.Text = "<< Quay lại";
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // ThongKeCongTy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 428);
            this.Controls.Add(this.back);
            this.Controls.Add(this.tabControl1);
            this.Name = "ThongKeCongTy";
            this.Text = "Thống kê công ty";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ngay)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.thang)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nam)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mon)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.loaimon)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.loaikh)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kenh)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.huytheokenh)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.huytheoloai)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView ngay;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView thang;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView nam;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView mon;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView loaimon;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView loaikh;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView kenh;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView huytheokenh;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView huytheoloai;
        private System.Windows.Forms.Label back;
    }
}