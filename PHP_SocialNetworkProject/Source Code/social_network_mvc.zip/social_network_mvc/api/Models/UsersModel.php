<?php  
	class UsersModel {

		//DB Stuff
		private $conn;
		private $table = 'users';

		//User properties
		public $u_id;
		public $f_name;
		public $l_name;
		public $user_name;
		public $describe;
		public $relationship;
		public $u_pass;
		public $u_email;
		public $u_country;
		public $u_gender;
		public $u_birthday;
		public $u_image;
		public $u_cover;
		public $u_reg_date;
		public $status;
		public $recovery_acc;
		public $title;
		public $num_post;
		public $num_ans;
		public $pos_status;
		public $block_status;
		public $position;


		//Constructor with DB
		public function __construct($db) {
			$this->conn = $db;
		}

		//Get Users
		public function read(){
			//Create query
			// $query = 'SELECT user_id, f_name, l_name, user_name, describe_user, relationship, user_pass, user_email, user_country, user_gender, user_birthday, user_image, user_cover, user_reg_date, status, recovery_account, title, num_post, num_ans, position, pos_status, block_status
			//  FROM ' . $this->table . ' ORDER BY user_id DESC';

			$query = 'SELECT *
			 FROM ' . $this->table . ' ORDER BY user_id DESC';

			// prepare statement
			$stmt = $this->conn->prepare($query);

			//Execute query
			$stmt->execute();
			return $stmt;
		}
	}
?>