<?php
	//headers
	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json; charset=UTF-8"');
	//header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	header("Access-Control-Allow-Headers: access");
 
	include_once('../Config/connection.php');
	include_once('../Models/UsersModel.php');

	//Instantiate DB & connect
	$connection = new Connection();
	$db = $connection->connect();

	//Instantiate User
	$user = new UsersModel($db);

	//User query	
	$res = $user->read();
	//Get row count
	$num = $res->rowCount();

	//Check if any users
	if ($num > 0) 
	{
		$users_arr = array();
		$users_arr['data'] = array();

		while($row = $res->fetch(PDO::FETCH_ASSOC)) {
			extract($row);

			$user_item = array(
				'user_id' => $user_id,
				'f_name' => $f_name,
				'l_name' => $l_name,
				'user_name' => $user_name,
				'describe_user' => $describe_user,
				'relationship' => $relationship,
				'user_pass' => $user_pass,
				'user_email' => $user_email,
				'user_country' => $user_country,
				'user_gender' => $user_gender,
				'user_birthday' => $user_birthday,
				'user_image' => $user_image,
				'user_cover' => $user_cover,
				'user_reg_date' => $user_reg_date,
				'status' => $status,
				'recovery_account' => $recovery_account,
				'title' => $title,
				'num_post' => $num_post,
				'num_ans' => $num_ans,
				'position' => $position,
				'pos_status' => $pos_status,
				'block_status' => $block_status
			);

			//Push to "data"
			array_push($users_arr['data'], $user_item);
		}

		//Turn to JSON & output
		echo json_encode($users_arr);

	} else {
		echo json_encode(
			array('message' => 'No Users Found')
		);
	}
?>