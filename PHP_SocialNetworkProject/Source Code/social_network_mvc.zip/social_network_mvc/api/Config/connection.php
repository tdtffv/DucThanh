<?php  
	class Connection {
		//DB Params
		private $host = 'localhost';
		private $db_name = 'social_network_mvc';
		private $username = 'root';
		private $db_pass = '';
		private $conn;

		//DB connection
		public function connect() {
			$this -> conn = null;

			try {
				$this->conn = new PDO('mysql:host=' . $this->host . ';dbname=' . $this->db_name, $this->username, $this->db_pass);
				//$this->conn->exec("set names utf8");
				$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch(PDOException $e) {
				echo 'Connection Error: ' . $e->getMessage();
			}
			return $this->conn;
		}
	}
?>