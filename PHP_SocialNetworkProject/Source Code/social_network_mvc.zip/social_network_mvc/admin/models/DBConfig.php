<?php 
    class Database {
    private $hostname = 'localhost';
    private $username = 'root';
    private $password = '';
    private $dbname = 'social_network_mvc';
    
    private $conn = NULL;
    private $result = NULL;

    // Create connection
    public function connect(){
        $this->conn = new mysqli($this->hostname, $this->username, $this->password, $this->dbname);    
    // Check connection
        if (!$this->conn) {
            die("Connection failed: " . mysqli_connect_error());
        } else{
            mysqli_set_charset($this->conn, 'utf8');
        }
    }

    public function execute($sql){
        $this->result = $this->conn->query($sql);
        return $this->result;
    }

    // public function getData($table)
    // {
    //     $sql = "select * from $table";
    //     $this->execute($sql)
    //     if($this->result){
    //         $data = mysqli_fetch_array($this->result);
    //     } else {
    //         $data = 0;
    //     }
    //     return $data;
    //}

    public function getAllData($table){
        if(!$this->result){
            return 0;
        } else{
            while($data = $this->getData($table)){
                    $data[] = $datas; 
                }
            }
        return $data;
    }
    
    public function InsertCate($CatID, $CatName)
    {
        $sql = "insert into category(cat_id, cat_name) values ('$CatID','$CatName')";
        return $this->execute($sql);
    }

}
?>