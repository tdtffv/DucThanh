<?php 
    //require_once "models/DBConfig.php";
    class categorys extends Database{
        public function InsertCate($CatID, $CatName)
        {
            $sql = "insert into category(cat_id, cat_name) values ('$CatID','$CatName')";
            return $this->execute($sql);
        }
    }
?>