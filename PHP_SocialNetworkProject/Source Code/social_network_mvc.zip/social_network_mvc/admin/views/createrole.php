<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ NGƯỜI DÙNG</h2>
        </div>
    </div>
</div>  
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">CẤP QUYỀN CHO NGƯỜI DÙNG</h5>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã người dùng</th>
                        <th scope="col">Tên người dùng</th>
                        <th scope="col">Xử lý</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="col">1</th>
                        <th scope="col">1</th>
                        <th scope="col">ducthanh_trinh_921118</th>
                        <th scope="col">    
                        <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">vi_duong_253938</th>
                        <th scope="col">    
                        <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">3</th>
                        <th scope="col">3</th>
                        <th scope="col">haiyen_vuthi_887749</th>
                        <th scope="col">    
                        <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">4</th>
                        <th scope="col">4</th>
                        <th scope="col">tiennhi_huynhngoc_884918</th>
                        <th scope="col">    
                            <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">5</th>
                        <th scope="col">5</th>
                        <th scope="col">nguyen_tran_448684</th>
                        <th scope="col">    
                            <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">6</th>
                        <th scope="col">6</th>
                        <th scope="col">thanh_t_572156</th>
                        <th scope="col">    
                            <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">7</th>
                        <th scope="col">7</th>
                        <th scope="col">tdtffc_980473</th>
                        <th scope="col">    
                        <button type="edit" class="btn btn-space btn-success">Cấp quyền MOD</i></button>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">HỦY QUYỀN MOD NGƯỜI DÙNG</h5>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã người dùng</th>
                        <th scope="col">Tên người dùng</th>
                        <th scope="col">Xử lý</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr>
                        <th scope="col">1</th>
                        <th scope="col">USER001</th>
                        <th scope="col">Lục Tiểu Pi</th>
                        <th scope="col">luctieupi@gmail.com</th>
                        <th scope="col">    
                            <button type="accept" class="btn btn-space btn-success"><i class="fas fa fas fa-plus-circle"></i></button>
                        </th>
                    </tr> -->
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>