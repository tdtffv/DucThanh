<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ BÀI ĐĂNG</h2>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">TẠO NHÃN MỚI</h5>
            <div class="card-body">
                <form id="validationform" data-parsley-validate="" novalidate="">
                    <div class="form-group row">
                        <label class="col-4 col-sm-3 col-form-label text-sm-right">Mã nhãn</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" placeholder="ID bao gồm chữ và số " class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-12 col-sm-3 col-form-label text-sm-right">Tên nhãn</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" data-parsley-minlength="6" placeholder="Tên hashtag" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row text-right">
                        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                            <button type="submit" class="btn btn-space btn-primary">Tạo mới<i></i></button>
                            <button class="btn btn-space btn-danger">Hủy</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">GÁN NHÃN CHO BÀI VIẾT</h5>
            <div class="card-body">
                <form id="validationform" data-parsley-validate="" novalidate="">
                    <div class="form-group row">
                        <label class="col-4 col-sm-3 col-form-label text-sm-right">Mã bài viết</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" placeholder="ID bao gồm chữ và số " class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-12 col-sm-3 col-form-label text-sm-right">Mã nhãn</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" data-parsley-minlength="6" placeholder="ID bao gồm chữ và số " class="form-control">
                        </div>
                    </div>
                    <div class="form-group row text-right">
                        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                            <button type="submit" class="btn btn-space btn-primary">Gán nhãn <i></i></button>
                            <button class="btn btn-space btn-danger">Xóa gán nhãn</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">DANH SÁCH NHÃN</h5>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mã nhãn</th>
                            <th scope="col">Tên nhãn</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="table-primary">
                            <th scope="row">1</th>
                            <td>HT001</td>
                            <td>Công nghệ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">DANH SÁCH BÀI VIẾT</h5>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mã bài viết</th>
                            <th scope="col">Mã nhãn</th>
                            <th scope="col">Tên bài viết</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="table-primary">
                            <th scope="row">1</th>
                            <td>BV001</td>
                            <td></td>
                            <td>Cách tối ưu win 10</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
