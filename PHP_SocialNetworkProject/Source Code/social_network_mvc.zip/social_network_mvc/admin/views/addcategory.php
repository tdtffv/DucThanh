<?php
   include "controllers/categoryController.php";
   include "models/category.php";
?>
<div class="container-fluid dashboard-content">
<div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">QUẢN LÝ DANH MỤC</h2>
                </div>
            </div>
        </div>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">THÊM DANH MỤC</h5>
            <div class="card-body">
                <form id="validationform" method="POST">
                    <div class="form-group row">
                        <label class="col-12 col-sm-3 col-form-label text-sm-right">Mã danh mục</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" name ="CatID" required="" placeholder="ID bao gồm chữ và số " class="form-control"></input>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-12 col-sm-3 col-form-label text-sm-right">Tên danh mục</label>
                        <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" name ="CatName" required="" data-parsley-minlength="6" placeholder="Tên danh mục" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row text-right">
                        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                            <button type="submit" class="btn btn-space btn-primary" name ="addNewCate" >Tạo mới</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<!-- </?php
include_once("./views/editcategory.php")
?> -->