<!-- <\?php
   include "controllers/categoryController.php";
   if(isset($_PUT["delete"])){
    echo "<script>alert('Xóa thành công')</script>";
  }
?> -->
<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">DANH SÁCH DANH MỤC</h2>
        </div>
    </div>
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">CHỈNH SỬA DANH MỤC</h5>
        <div class="card-body">
            <table class="table">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Mã danh mục</th>
                    <th scope="col">Tên danh mục</th>
                    <th scope="col">Xử lý</th>
                </tr>
                <?php
                   include "controllers/categoryController.php";
                ?>
                <!-- <tr>
                    <th scope="col">1</th>
                    <th scope="col">1</th>
                    <th scope="col">Technology</th>
                    <th scope="col">    
                        <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr> -->
                <tr>
                    <th scope="col">1</th>
                    <th scope="col">2</th>
                    <th scope="col">Economy</th>
                    <th scope="col">    
                        <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr>
                <tr>
                    <th scope="col">2</th>
                    <th scope="col">3</th>
                    <th scope="col">Sport</th>
                    <th scope="col">    
                        <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr>
                <tr>
                    <th scope="col">3</th>
                    <th scope="col">4</th>
                    <th scope="col">Life</th>
                    <th scope="col">    
                        <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                        <button  type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr>
                <tr>
                    <th scope="col">4</th>
                    <th scope="col">5</th>
                    <th scope="col">Food</th>
                    <th scope="col">    
                        <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr>
                <tr>
                    <th scope="col">5</th>
                    <th scope="col">6</th>
                    <th scope="col">School</th>
                    <th scope="col">    
                    <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                    <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                    </th>
                </tr>
                
            </table>
        </div>
    </div>
</div>
</div>
<!-- / -->