<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ BÀI ĐĂNG</h2>
        </div>
    </div>
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">XÓA BÀI VIẾT</h5>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã bài viết</th>
                        <th scope="col">Tác giả</th>
                        <th scope="col">Nội dung</th>
                        <th scope="col">Danh mục</th>
                        <th scope="col">Xử lý</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr>
                        <th scope="col">1</th>
                        <th scope="col">15</th>
                        <th scope="col">vi_duong_253938</th>
                        <th scope="col">How to create more money?</th>
                        <th scope="col">Economy</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        <button type="check" class="btn btn-space btn-success"><i class="fas fa fas fa-check"></i></button>
                        </th>
                    </tr> -->
                    <!-- <tr>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">Why math is so hard?</th>
                        <th scope="col">2</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">3</th>
                        <th scope="col">3</th>
                        <th scope="col">4</th>
                        <th scope="col">How to fix this bug</th>
                        <th scope="col">1</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">4</th>
                        <th scope="col">4</th>
                        <th scope="col">2</th>
                        <th scope="col">Is anybody want to go swimming with me?</th>
                        <th scope="col">3</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">5</th>
                        <th scope="col">5</th>
                        <th scope="col">3</th>
                        <th scope="col">Love your body, love your self</th>
                        <th scope="col">4</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">6</th>
                        <th scope="col">6</th>
                        <th scope="col">3</th>
                        <th scope="col">How to create more and more code?</th>
                        <th scope="col">1</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">7</th>
                        <th scope="col">7</th>
                        <th scope="col">2</th>
                        <th scope="col">How to stop being bored?</th>
                        <th scope="col">4</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">8</th>
                        <th scope="col">8</th>
                        <th scope="col">5</th>
                        <th scope="col">I need to find some recipe about cooking with egg?</th>
                        <th scope="col">5</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">9</th>
                        <th scope="col">9</th>
                        <th scope="col">5</th>
                        <th scope="col">How to clean shoes without touching it?</th>
                        <th scope="col">3</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">10</th>
                        <th scope="col">10</th>
                        <th scope="col">3</th>
                        <th scope="col">Do you guys like Thai food?</th>
                        <th scope="col">5</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">11</th>
                        <th scope="col">11</th>
                        <th scope="col">3</th>
                        <th scope="col">Why is pizza popular?</th>
                        <th scope="col">5</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">12</th>
                        <th scope="col">12</th>
                        <th scope="col">1</th>
                        <th scope="col">How to clean shoes clearly?</th>
                        <th scope="col">4</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">Why math is so hard?</th>
                        <th scope="col">2</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">Why math is so hard?</th>
                        <th scope="col">2</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">2</th>
                        <th scope="col">Why math is so hard?</th>
                        <th scope="col">2</th>
                        <th scope="col">    
                        <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr> -->

                </tbody>
            </table>
        </div>
    </div>
</div>
</div>