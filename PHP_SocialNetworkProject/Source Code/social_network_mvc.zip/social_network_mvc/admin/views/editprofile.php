<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ TÀI KHOẢN</h2>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header">CHỈNH SỬA THÔNG TIN TÀI KHOẢN</h5>
            <div class="card-body">
                <form action="#" id="basicform" data-parsley-validate="">
                    <div class="form-group">
                        <label for="inputUserName">Tên đăng nhập</label>
                        <input id="inputUserName" type="text" name="name" data-parsley-trigger="change" required="" placeholder=" User name" autocomplete="off" class="form-control">
                    </div>
                    <!-- <div class="form-group">
                        <label for="inputEmail">Email</label>
                        <input id="inputEmail" type="email" name="email" data-parsley-trigger="change" required="" placeholder=" Email" autocomplete="off" class="form-control">
                    </div> -->
                    <div class="form-group">
                        <label for="inputPassword">Mật khẩu</label>
                        <input id="inputPassword" type="password" placeholder=" Password" required="" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="inputRepeatPassword">Nhập lại mật khẩu</label>
                        <input id="inputRepeatPassword" data-parsley-equalto="#inputPassword" type="password" required="" placeholder=" Password" class="form-control">
                    </div>
                    <div class="row">
                        <div class="col-sm-12 pl-0">
                            <p class="text-right">
                                <button type="submit" class="btn btn-space btn-primary">Lưu</button>
                            </p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>   
</div>
</div>

