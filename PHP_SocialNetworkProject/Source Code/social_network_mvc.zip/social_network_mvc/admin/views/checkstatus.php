<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ BÀI ĐĂNG</h2>
        </div>
    </div>
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">DUYỆT BÀI VIẾT</h5>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã bài viết</th>
                        <th scope="col">Tác giả</th>
                        <th scope="col">Nội dung</th>
                        <th scope="col">Danh mục</th>
                        <th scope="col">Xử lý</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr>
                        <th scope="col">1</th>
                        <th scope="col">56</th>
                        <th scope="col">thanh t</th>
                        <th scope="col">hello shit</th>
                        <th scope="col">Food</th>
                        <th scope="col"> 
                            <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>   
                            <button type="check" class="btn btn-space btn-success"><i class="fas fa fas fa-check"></i></button>
                        </th>
                    </tr> -->
                    <tr>
                        <td colspan="9">
                            <button type="edit" class="btn btn-space btn-success float-right">Duyệt tự động </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>