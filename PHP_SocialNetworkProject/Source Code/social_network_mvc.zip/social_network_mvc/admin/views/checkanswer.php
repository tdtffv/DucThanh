<div class="container-fluid dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ BÀI ĐĂNG</h2>
        </div>
    </div>
</div>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 co-12">
            <section class="card card-fluid">
                <h5 class="card-header drag-handle">1    Why math is so hard? </h5>
                <div class="dd" id="nestable">
                    <!-- <li class="dd-item" data-id="1">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hello</div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li> -->
                    <li class="dd-item" data-id="2">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hi </div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li>
                </div>
            </section>
        </div>

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 co-12">
            <section class="card card-fluid">
                <h5 class="card-header drag-handle">2    What's going on with my laptop? </h5>
                <div class="dd" id="nestable">
                    <li class="dd-item" data-id="1">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hello</div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li>
                    <li class="dd-item" data-id="2">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hi </div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li>
                </div>
            </section>
        </div>

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 co-12">
            <section class="card card-fluid">
                <h5 class="card-header drag-handle">3    How to fix this bug </h5>
                <div class="dd" id="nestable">
                    <li class="dd-item" data-id="1">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hello</div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li>
                    <li class="dd-item" data-id="2">
                        <div class="dd-handle"> <span class="drag-indicator"></span>
                            <div> Hi </div>
                            <div class="dd-nodrag btn-group ml-auto">
                                <button class="btn btn-sm btn-outline-light">
                                    <i class="far fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </li>
                </div>
            </section>
        </div>
</div>