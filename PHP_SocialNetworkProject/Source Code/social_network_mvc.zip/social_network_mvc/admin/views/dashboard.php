    <div class="container-fluid dashboard-content ">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">DASHBOARD</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card border-3 border-top border-top-primary">
                    <div class="card-body">
                        <h5 class="text-muted">Bài chờ duyệt</h5>
                        <div class="metric-value d-inline-block">
                            <h1 class="mb-1">1</h1>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card border-3 border-top border-top-primary">
                    <div class="card-body">
                        <h5 class="text-muted">Người dùng mới</h5>
                        <div class="metric-value d-inline-block">
                            <h1 class="mb-1">1</h1>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                <div class="card border-3 border-top border-top-primary">
                    <div class="card-body">
                        <h5 class="text-muted">Người dùng trong hệ thống</h5>
                        <div class="metric-value d-inline-block">
                            <h1 class="mb-1">8</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>