<div class="container-fluid  dashboard-content">
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">QUẢN LÝ NGƯỜI DÙNG</h2>
        </div>
    </div>
</div>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="card">
        <h5 class="card-header">CHỈNH SỬA NGƯỜI DÙNG</h5>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Mã người dùng</th>
                        <th scope="col">Tên người dùng</th>
                        <th scope="col">Email</th>
                        <th scope="col">Xử lý</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="col">1</th>
                        <th scope="col">USER001</th>
                        <th scope="col">Lục Tiểu Pi</th>
                        <th scope="col">luctieupi@gmail.com</th>
                        <th scope="col">    
                            <button type="edit" class="btn btn-space btn-warning"><i class="fas fa fas fa-pencil-alt"></i></button>
                            <button type="delete" class="btn btn-space btn-danger"><i class="fas fa fas fa-trash"></i></button>
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>