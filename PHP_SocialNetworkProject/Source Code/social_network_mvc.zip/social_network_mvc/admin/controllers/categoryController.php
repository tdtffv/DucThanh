<?php
    if(isset($_POST["addNewCate"])){
        $CatID = $_POST["CatID"];
        $CatName = $_POST["CatName"];
        if($db->InsertCate($CatID, $CatName)){
            return $db;
            // echo "<script>alert('Thêm thành công')</script>";
        }
    }

    // $table = "category";
    // $db->getData($table);
    // $data = $db->getAllData($table);

?>