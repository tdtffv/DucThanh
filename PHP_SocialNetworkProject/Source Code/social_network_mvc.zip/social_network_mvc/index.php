<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>UDPT-16 Login and Sign up</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>
<body>
  <div class="row">
    <div class="col-sm-12">
      <div class="well">
        <center><h1 style="color: white;">UDPT-16</h1></center>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-6" style="left: 0.5%;">
      <img src="public/images/login.jpg" class="img-rounded" title="UDPT-16" width="720px" height="550px">
    </div>
    <div class="col-sm-6" style="left: 8%;">
      <img src="public/images/logo.png" class="img-rounded" title="UDPT-16" width="130px" height="130px">
      <h2>
        <strong>See what's happening in <br> the world right now</strong>
      </h2>
      <br><h4><strong>Join with us today</strong></h4>
      <form method="post" action="">
        <button id="signup" class="btn btn-info btn-lg" name="signup">Sign up</button><br><br>
        <?php
          if(isset($_POST['signup'])){
            echo "<script>window.open('user/?controller=userController&action=signup_view','_self')</script>";
          }
        ?>
        <button id="login" class="btn btn-info btn-lg" name="login">Login</button><br><br>
        <?php
          if(isset($_POST['login'])){
            echo "<script>window.open('user/?controller=userController&action=login_view','_self')</script>";
          }
        ?>
        <button id="guest" class="btn btn-info btn-lg" name="guest">For Guest</button><br><br>
        <?php
          if(isset($_POST['guest'])){
            echo "<script>window.open('guest/?controller=guestController&action=home','_self')</script>";
          }
        ?>  
        <button id="admin" class="btn btn-info btn-lg" name="admin">Admin</button><br><br>
        <?php
          if(isset($_POST['admin'])){
            echo "<script>window.open('admin/index.php','_self')</script>";
          }
        ?>  
      </form>
    </div>
  </div>
</body>
</html>