<!DOCTYPE html>

<link rel="stylesheet" type="text/css" href="public/css/ranking_detail.css">

<tr>
	<td><?php echo "#".$rank; ?></td>
	<td>
		<div class='row'>
			<div class='col-sm-5'>
				<div class='row'>
					<div class='col-sm-4'>
						<a href=''>
							<img id="img" class="img-circle" src='public/images/<?php echo $user_image;?>' width=60px height=60px title='<?php echo $user_name;?>'/>
						</a>
					</div>
					<div class='col-sm-8'>
						<a id="user-rank" href=''>
							<strong><h4><?php echo $user_name;?></h4></strong>
						</a>
					</div>
				</div>
			</div>
		</div>
	</td>
	<td id="user-scores"><?php echo $scores; ?></td>
	<td><?php echo $title; ?></td>
</tr>