<link rel="stylesheet" type="text/css" href="public/css/header.css">
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" aria-expanded="false">
			<span class="sr-only"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="?controller=guestController&action=home" id="logo">UDPT-16</a>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">

			<li><a href="?controller=guestController&action=home">Home</a></li>
	        <li><a href="http://localhost/social_network_mvc/user/?controller=userController&action=main">Profile</a></li></li>
			<li><a href="http://localhost/social_network_mvc/user/?controller=userController&action=main">Find People</a></li>
			<li><a href="app/chatbot/chatbot.php">Chatbot</a></li>
			<li><a href="?controller=guestController&action=ranking">Ranking</a></li>

			<li class='dropdown'>
					<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span><i class='glyphicon glyphicon-chevron-down'></i></span></a>
					<ul class='dropdown-menu'>
						<li>
							<a href='http://localhost/social_network_mvc/user/?controller=userController&action=signup_view'>Signup</a>
						</li>
						<li>
							<a href='http://localhost/social_network_mvc/user/?controller=userController&action=login_view'>Login</a>
						</li>
					</ul>
				</li>

			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<form class="navbar-form navbar-left" method="get" action="">
						<div class="form-group">
							<input type="text" class="form-control" name="user_query" placeholder="Search..." id="search_query" autocomplete="off">
						</div>
						<button type="submit" class="btn btn-info" name="search" id="search">Search</button>
						<input type="hidden" name="controller" value="guestController">
						<input type="hidden" name="action" value="search_post">
					</form>
				</li>
			</ul>
		</div>
	</div>
</nav>