<!DOCTYPE html>
<?php

require_once('public/template/header.php');

?>
<html>
<head>
	<title>Home Page</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/home.css">
</head>
<body>

<div class="row">
	<div id="insert_post" class="col-sm-12">
		<center>
		<form action="" method="post" id="f" enctype="multipart/form-data">
			<textarea class="form-control" id="content" rows="4" name="content" placeholder="What's in your mind?"></textarea><br>
			<select name="cat_id" id="cat_id" class="form-control">
				<option value="" disabled="">---Choose category---</option>
				<?php
					foreach($cats as $cat):
				?>
					<option value="<?php echo $cat['cat_id'] ?>"><?php echo $cat['cat_name'] ?></option>
				<?php
					endforeach;
				?>
			</select><br>
			<button id="btn-post" class="btn btn-info" name="sub">Post</button>
		</form>
		</center>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<center><h2><strong>News Feed</strong></h2><br></center>
		<form method="post" action=""><center>
			<button class="btn btn-default" name='desc'>New Posts</button>
			<button class="btn btn-default" name='asc'>Last Posts</button><br><br>
		</center></form>
	</div>
</div>
</body>
</html>