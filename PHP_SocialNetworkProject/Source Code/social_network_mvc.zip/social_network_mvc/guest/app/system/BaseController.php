<?php

class BaseController
{
    public function require_model($model_name)
    {
    	require_once('app/models/'.$model_name.'.php');
        $model_name = new $model_name();
        return $model_name;
    }

    public function require_view($view_name)
    {
    	require_once('app/views/'.$view_name.'.php');
        $view_name = new $view_name();
        return $view_name;
    }

    public function header()
    {
        $view = $this->require_view('mainView');
        
        $user = $this->require_model('user');

        $usermail = $_SESSION['user_email'];
        $row = $user->get_user($usermail);
                    
        $user_id = $row['user_id']; 
        $user_name = $row['user_name'];
        $first_name = $row['f_name'];
        $last_name = $row['l_name'];
        $describe_user = $row['describe_user'];
        $relationship_status = $row['relationship'];
        $user_pass = $row['user_pass'];
        $user_email = $row['user_email'];
        $user_country = $row['user_country'];
        $user_gender = $row['user_gender'];
        $user_birthday = $row['user_birthday'];
        $user_image = $row['user_image'];
        $user_cover = $row['user_cover'];
        $recovery_account = $row['recovery_account'];
        $register_date = $row['user_reg_date'];
        $status = $row['status'];
        $title = $row['title'];
        $num_post = $row['num_post'];
        $num_ans = $row['num_ans'];
        $position = $row['position'];
        $pos_status = $row['pos_status'];
        $block_status= $row['block_status'];
        
        $post = $this->require_model('post');       
                    
        $num_post = $post->get_num_user_posts($user_id);
        $view->header($user_id, $user_name, $first_name, $last_name, $describe_user, $relationship_status, $user_pass, $user_email, $user_country, $user_gender, $user_birthday, $user_image, $user_cover, $recovery_account, $register_date, $status, $title, $num_post, $num_ans, $position, $pos_status, $block_status);
    }
} 
?>