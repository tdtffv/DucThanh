<?php 

class BaseModel
{
    public function connect_dtb(){
        $con = mysqli_connect("localhost","root","","social_network_mvc");
        if(mysqli_connect_errno()){
            echo "Error:".mysqli_connect_error();
        }
        return $con;
    }

}


?>