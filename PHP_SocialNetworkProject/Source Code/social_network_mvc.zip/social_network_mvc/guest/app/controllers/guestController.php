<?php

require_once('app/system/BaseController.php');
session_start();

class guestController extends BaseController
{	

    public function home()
    {
    	$guest = $this->require_model('guestModel');
        $cats = $guest->get_category();

    	$view = $this->require_view('guestView');
		$view->home($cats);

        $per_page = 10;

        if(isset($_GET['page'])){
            $page = $_GET['page'];
        }else    
        {
            $page = 1;
        }

        $start_from = ($page - 1) * $per_page;

        if(isset($_POST['asc'])){
            $cond = 0;
        }
        else{
            $cond = 1;
        }

        if(isset($_POST['sub'])){
            echo "<script>alert('Please login first!')</script>";
        }

        $run_posts = $guest->get_posts($start_from,$per_page,$cond);

        foreach($run_posts as $row_posts){

            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
            $contents = substr($row_posts['content'], 0,40);
            $post_cat = $row_posts['post_cat'];
            $post_date = $row_posts['post_date'];
            $content = $guest->convert_clickable_links($contents);

            $cat_name = $guest->get_category_by_id($post_cat);

            $row_user = $guest->get_user_by_id($user_id);

            $user_name = $row_user['user_name'];
            $user_image = $row_user['user_image'];

            $rateavg = $guest->get_rate_avg($post_id);

            $rateavg_sub = $guest->get_rate_avg_sub($rateavg);

            //now displaying posts from database

            if(strlen($content) >= 1){
                $view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);
            }
        }

        $total_posts = $guest->get_num_posts();
        $total_pages = ceil($total_posts / $per_page);

        echo"
        <center>
        <ul class='pagination'>
            <li class='page-item'>
                <a href='?controller=guestController&action=home&page=1'>First Page</a>
            </li>
        ";

        for ($i=1; $i <= $total_pages ; $i++) { 
            echo"
            <li class='page-item'>
                <a href='?controller=guestController&action=home&page=$i'>$i</a>
            </li>
            ";
        }

        echo"
        <li class='page-item'>
            <a href='?controller=guestController&action=home&page=$total_pages'>Last Page</a>
        </li>
        </ul>";
    }

     public function post_detail()
    {
        $guest = $this->require_model('guestModel');

        $view = $this->require_view('guestView');

        $get_id = $_GET['post_id'];
        
        $run_posts = $guest->get_post_by_id($get_id,0);
        foreach ($run_posts as $row_posts) {
            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
            $contents = $row_posts['content'];
            $post_cat = $row_posts['post_cat'];
            $post_date = $row_posts['post_date'];
            $content = $guest->convert_clickable_links($contents);
        }
        
        $view->post_detail($post_id);

        $cat_name = $guest->get_category_by_id($post_cat);

        $c_like = $guest->get_num_like($post_id,0);

        $c_rate1 = $guest->get_num_rate($post_id,1);

        $c_rate2 = $guest->get_num_rate($post_id,2);

        $c_rate3 = $guest->get_num_rate($post_id,3);

        $c_rate4 = $guest->get_num_rate($post_id,4);

        $c_rate5 = $guest->get_num_rate($post_id,5);

        $row_user = $guest->get_user_by_id($user_id);

        $user_name = $row_user['user_name'];
        $user_image = $row_user['user_image'];

        if(strlen($content) >= 1){
            
        echo"
        <div class='row'>
            <div class='col-sm-3'>
            </div>
            <div id='posts' class='col-sm-6'>
                <div class='row'>
                    <div class='col-sm-2'>
                    <p><img src='public/images/$user_image' class='img-circle' width='80px' height='80px'></p>
                    </div>
                    <div class='col-sm-6'>
                        <h3><a style='text-decoration:none; cursor:pointer; color #3897f0;' href=''>$user_name</a></h3>
                        <h4><small style='color:black;'>Updated a post on <strong>$post_date</strong></small></h4>
                    </div>
                    <div class='col-sm-4'>
                        <h4 style='color: black; float: right; color: grey;'><strong>$cat_name</strong></h4>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-12'>
                        <h3><p>$content</p></h3>
                    </div>
                </div><br>
                <form action='' method='post'>
                <select name='rateval' class='btn'>
                        <option value='5'>Excellence ($c_rate5)</option>
                        <option value='4'>Good ($c_rate4)</option>
                        <option value='3'>Average ($c_rate3)</option>
                        <option value='2'>Poor ($c_rate2)</option>
                        <option value='1'>Very Poor ($c_rate1)</option>
                </select>
                <input type='submit' class='btn btn-info' value='Rate'>
                </form>
                <a href='' style='float:right;'>
                    <button class='btn btn-danger'>Report</button>
                </a>
                <a href='' style='float:right;'>
                    <button class='btn btn-outline-primary'>Like($c_like)</button>
                </a>
            </div>
            <div class='col-sm-3'>
            </div>
        </div><br><br>
        ";
        }
        $this->get_answers();
    }

    public function get_answers()
    {
        
        $guest = $this->require_model('guestModel');

        $get_id = $_GET['post_id'];
        
        $run_ans = $guest->get_ans_by_id($get_id,0);

        if($run_ans != NULL){

            foreach ($run_ans as $row) {
                $content = $row['content'];
                $ans_name = $row['user_ans'];
                $ans_date = $row['ans_date'];
                $ans_id = $row['ans_id'];
                $ans = $guest->convert_clickable_links($content);

                $c_like = $guest->get_num_like($ans_id,1);

                echo "
                <div class='row'>
                    <div class='col-md-6 col-md-offset-3'>
                        <div class='panel panel-info' style='border: 1px solid blue; border-radius: 10px;'>
                            <div class='panel-body'>
                                <div>
                                    <h5><strong>$ans_name</strong><i> answered</i> on $ans_date</h5>
                                    <p class='text-primary' style='margin-left:5px;font-size:17px;'>$ans</p>
                                    <a href='' style='float:right;'>
                                        <button class='btn btn-outline-primary'>Like($c_like)</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                ";
            }
        }
    }

    public function search_post()
    {
        $guest = $this->require_model('guestModel');

        $view = $this->require_view('guestView');
        $view->search_post();

        if (isset($_GET['search'])) 
        {
            $search_query = htmlentities($_GET['user_query']);  
        }

        if($search_query != NULL){

            $run_posts = $guest->get_post_search($search_query);

        if($run_posts != NULL){

            foreach ($run_posts as $row_posts) {
                $post_id = $row_posts['post_id'];
                $user_id = $row_posts['author'];
                $contents = $row_posts['content'];
                $post_cat = $row_posts['post_cat'];
                $post_date = $row_posts['post_date'];
                $content = $guest->convert_clickable_links($contents);

                $cat_name = $guest->get_category_by_id($post_cat);

                $row_user = $guest->get_user_by_id($user_id);

                $user_name = $row_user['user_name'];
                $f_name = $row_user['f_name'];
                $l_name = $row_user['l_name'];
                $user_image = $row_user['user_image'];

                $rateavg = $guest->get_rate_avg($post_id);

                $rateavg_sub = $guest->get_rate_avg_sub($rateavg);

                if(strlen($content) >= 1){
                    echo"
                        <div class='row'>
                            <div class='col-sm-3'></div>
                            <div id='posts' class='col-sm-6' style='border:2px solid black; border-radius:20px; padding: 20px;'>
                                <div class='row'>
                                    <div class='col-sm-2'>
                                    <p><img src='public/images/$user_image' class='img-circle' width='80px' height='80px'></p>
                                    </div>
                                    <div class='col-sm-6'>
                                        <h3><a style='text-decoration:none; cursor:pointer; color #3897f0;' href=''>$user_name</a></h3>
                                        <h4><small style='color:black;'>Updated a post on <strong>$post_date</strong></small></h4>
                                    </div>
                                    <div class='col-sm-4'>
                                        <h4 style='color: black; float: right; color: grey;'><strong>$cat_name</strong></h4>
                                    </div>
                                </div>
                                <div class='row'>
                                    <div class='col-sm-12'>
                                        <h3><p>$content</p></h3>
                                    </div>
                                </div><br>
                                <h5>Avergare Rate: <strong id='rate-avg' style='border: 1px solid black;border-radius:10px;padding:4px 6px;'>$rateavg_sub</strong></h5>
                                <a href='' style='float:right;'>
                                    <button class='btn btn-danger'>Report</button>
                                </a>
                                <a href='?controller=guestController&action=post_detail&post_id=$post_id' style='float:right;'>
                                    <button class='btn btn-info'>View</button>
                                </a>
                            </div>
                            <div class='col-sm-3'></div>
                        </div><br><br>
                        ";
                    }
                }
            }else{
                echo '<hr><center><h3><i>There is no post here</h3></i></center>';
            }
        }
    }

    public function ranking()
    {
        
        $view = $this->require_view('guestView');
        $r_view = $view->rank();

        $this->ranking_detail();
        
        echo "
                </table>
                    </form>
                </div>
                <div class='col-sm-2'></div>
            </div>
            </body>
            </html>
        ";
    }

    public function ranking_detail()
    {
        $guest = $this->require_model('guestModel');
        $view = $this->require_view('guestView');

        $rank = 0;
        $temp_score = 0;

        $run_rank = $guest->get_user_rank();

        foreach ($run_rank as $row_rank) {
            
            if($temp_score != $row_rank['scores'])
                $rank++;
             

            $user_name = $row_rank['user_name'];
            $user_id = $row_rank['user_id'];
            $user_image = $row_rank['user_image'];
            $scores = $row_rank['scores'];

            if($scores >= 50){
                $title = 'Featured';
            }else if($scores >= 30){
                $title = 'Active';
            }else{
                $title = 'Normal';
            }

            $up_title_val = array(
                "title='$title'"
            );

            $up_title_cond = array(
                "user_id='$user_id'"
            );

            $update = $guest->update_ranking($up_title_val,$up_title_cond);

            $rd_view = $view->rank_detail($user_name, $user_id, $user_image, $title, $scores, $rank);
                 
            $temp_score = $scores;
        }
    }

    public function search_hashtag() 
    {
        $guest = $this->require_model('guestModel');

        $view = $this->require_view('guestView');

        if(isset($_GET['hashtag'])) {
            $tags = ($_GET['hashtag']);
            $get_post_hash = $guest->get_post_by_hashtag($tags);
        }

        $tag_view = $view->search_hashtag($tags);

        if($get_post_hash != NULL){
            foreach ($get_post_hash as $row_posts) {

                $post_id = $row_posts['post_id'];
                $user_id = $row_posts['author'];
                $content = $guest->convert_clickable_links($row_posts['content']);
                $post_cat = $row_posts['post_cat'];
                $post_date = $row_posts['post_date'];
                $hashtag = $row_posts['hashtag'];

                $cat_name = $guest->get_category_by_id($post_cat);

                $row_user = $guest->get_user_by_id($user_id);

                $user_name = $row_user['user_name'];
                $f_name = $row_user['f_name'];
                $l_name = $row_user['l_name'];
                $user_image = $row_user['user_image'];

                $rateavg = $guest->get_rate_avg($post_id);

                $rateavg_sub = $guest->get_rate_avg_sub($rateavg);

                $post_view = $view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);

            }
        }
    }

    public function gethashtags($message)
    {
        //Match the hashtags
        preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $message, $matchedHashtags);
        $hashtag = '';
        // For each hashtag, strip all characters but alpha numeric
        if(!empty($matchedHashtags[0])) {
            foreach($matchedHashtags[0] as $match) {
                $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
            }
        }
        //to remove last comma in a string
        return rtrim($hashtag, ',');
    }

}