<?php

require_once('app/system/BaseModel.php');

class guestModel extends BaseModel
{	
	public function get_category()
	{
		$con = $this->connect_dtb();

		$select_cat = "select * from category ORDER by cat_name";
		$result_cat = $con->query($select_cat);
		$cat = array();

        if($result_cat->num_rows>0){
            while ($cat = mysqli_fetch_assoc($result_cat)) {
                $cats[]=$cat;
            }
        }
        // print_r($cats);
		return $cats;
	}

	public function get_posts($start_from,$per_page,$cond)
    {
        $con = $this->connect_dtb();
        if($cond == 0){
            $sql = "select * from post where status = 0 ORDER by 1 LIMIT $start_from, $per_page";
        }else{
            $sql = "select * from post where status = 0 ORDER by 1 DESC LIMIT $start_from, $per_page";
        }
        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }
        else{
            $posts = NULL;
        }

        return $posts;
    }

    public function get_category_by_id($cat_id)
	{
		$con = $this->connect_dtb();

		$select_cat = "select * from category where cat_id = '$cat_id'";
		$result_cat = $con->query($select_cat);
		$row_cat = mysqli_fetch_array($result_cat);

        $cat_name = $row_cat['cat_name'];
		
		return $cat_name;
	}

	public function get_user_by_id($user_id)
    {
    	$con = $this->connect_dtb();

    	$get_user = "select * from users where user_id='$user_id' and status='verified'"; 
		$run_user = $con->query($get_user);
		return $row = mysqli_fetch_array($run_user);
    }

    public function get_rate_avg($post_id)
    {
        $con = $this->connect_dtb();
        $sql = "select avg(rate) as rate_avg from post_rate where post_id = '$post_id'";
        $res = $con->query($sql);
        $row_rateavg = mysqli_fetch_array($res);
        $rateavg = $row_rateavg['rate_avg'];
        $rateavg = intval($rateavg);

        return $rateavg;
    }

    public function get_rate_avg_sub($rateavg)
    {
        if($rateavg == 1)
        {
            $rateavg_sub = 'Very Poor';
        }else if($rateavg == 2) {
            $rateavg_sub = 'Poor';
        }else if($rateavg == 3) {
            $rateavg_sub = 'Average';
        }else if($rateavg == 4) {
            $rateavg_sub = 'Good';
        }else if($rateavg == 5) {
            $rateavg_sub = 'Excellence';
        }else{
            $rateavg_sub = 'None';
        }

        return $rateavg_sub;
    }

    public function get_num_posts()
    {
        $con = $this->connect_dtb();

        $sql = "select * from post";

        $res = $con->query($sql);
        $post = $res->num_rows;

        return $post;
    }

    public function get_post_by_id($id,$val)
    {
        $con = $this->connect_dtb();

        if($val == 0){
            $sql = "select * from post where post_id='$id' and status = 0 ORDER by 1 DESC";
        }else if($val == 1){
            $sql = "select * from post where author='$id' and status = 0 ORDER by 1 DESC";
        }

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }
        else{
            $posts = NULL;
        }
        // print_r($posts);
        return $posts;
    }

    public function get_num_like($id,$val)
    {
        $con = $this->connect_dtb();
        if($val == 0){
            $get = "select * from post_like where post_id=$id";
        }else if($val == 1){
            $get = "select * from ans_like where ans_id=$id";
        }
        $res = $con->query($get);
        $count = $res->num_rows;

        return $count;
    }

    public function get_num_rate($post_id,$rate)
    {
        $con = $this->connect_dtb();

        $get = "select * from post_rate where post_id=$post_id and rate='$rate'";
        $res = $con->query($get);
        $count = $res->num_rows;

        return $count;
    }

    public function get_user($user)
    {
        $con = $this->connect_dtb();

        $get_user = "select * from users where user_email='$user' and status='verified'"; 
        $run_user = $con->query($get_user);
        return $row = mysqli_fetch_array($run_user);
    }

    public function get_ans_by_id($id,$val)
    {
        $con = $this->connect_dtb();
        
        if($val == 0){
            $sql = "select * from answers where post_id='$id' ORDER by 1 DESC";
        }else if($val == 1){
            $sql = "select * from answers where ans_id='$id' ORDER by 1 DESC";
        }

        $res = $con->query($sql);
        $ans = array();
        if($res->num_rows > 0){
            while ($ans = mysqli_fetch_array($res)) {
                $answers[]=$ans;
            }
        }
        else{
            $answers = NULL;
        }

        return $answers;
    }

    public function get_post_search($word)
    {
        $con = $this->connect_dtb();

        $sql = "select p.* from post p, category c where p.post_cat=c.cat_id and (p.content like '%$word%' or c.cat_name like '%$word%') and p.status = 0  ORDER by 1 DESC";

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }else{
            $posts = NULL;
        }

        return $posts;
    }

    public function get_user_rank()
    {
        $con = $this->connect_dtb();

        $get_rank = "select r.*,u.* from users u, ranking r where u.user_id=r.user_id and u.status='verified' and month(NOW())=r.month and year(NOW())=r.year ORDER by r.scores DESC LIMIT 0, 10";

        $run_rank = $con->query($get_rank);
        $res = array();
        if($run_rank->num_rows > 0){
            while ($res = mysqli_fetch_array($run_rank)) {
                $rank[]=$res;
            }
        }
        else{
            $rank = NULL;
        }
        // print_r($rank);
        return $rank;
    }

    public function update_ranking($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update ranking set ".implode(',', $val)." where ".implode(" and ", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

    public function convert_clickable_links($content)
    {
        $expression = "/#+([a-zA-Z0-9_]+)/";  
        $hashtag = preg_replace($expression, '<a href="?controller=guestController&action=search_hashtag&hashtag=$1">#$1</a>', $content);
        return $hashtag;  
    }

    public function get_post_by_hashtag($tags)
    {
        $con = $this->connect_dtb();

        $sql = "select * from post where hashtag like '%$tags%' AND status = 0 ORDER by 1 DESC";

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }else{
            $posts = NULL;
        }

        return $posts;

    }

}