<?php 

class guestView
{
    public function header()
    {
        require_once('public/template/header.php');
    }

    public function home($cats)
    {
        require_once('public/template/home.php');
    }

    public function chatbot()
    {
        require_once('public/template/chatbot.php');
    }

    public function post_detail($post_id)
    {
        require_once('public/template/post_detail.php');
    }

    public function search_post()
    {
        require_once('public/template/search_post.php');
    }

    public function rank()
    {
        require_once('public/template/ranking.php');
    }

    public function rank_detail($user_name, $user_id, $user_image, $title, $scores, $rank)
    {
        require('public/template/ranking_detail.php');
    }

    public function get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id)
    {
        require('public/template/get_posts.php');
    }

    public function search_hashtag($hashtag)
    {
        require_once('public/template/search_hashtag.php');
    }

}
?>