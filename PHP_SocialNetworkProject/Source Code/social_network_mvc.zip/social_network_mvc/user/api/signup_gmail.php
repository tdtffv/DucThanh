<?php
// session_start();
$con = mysqli_connect("localhost","root","","social_network_mvc");
include("config/config.php");

$login_button = '';
//This $_GET["code"] variable value received after user has login into their Google Account redirct to PHP script then this variable value has been received

if(isset($_GET["code"]))
{
	//It will Attempt to exchange a code for an valid authentication token.
 	$token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);

 	//This condition will check there is any error occur during geting authentication token. If there is no any error occur then it will execute if block of code/
	 if(!isset($token['error']))
	 {
		  //Set the access token used for requests
		  $google_client->setAccessToken($token['access_token']);

		  //Store "access_token" value in $_SESSION variable for future use.
		  $_SESSION['access_token'] = $token['access_token'];

		  //Create Object of Google Service OAuth 2 class
		  $google_service = new Google_Service_Oauth2($google_client);

		  //Get user profile data from google
		  $data = $google_service->userinfo->get();

		  //Below you can find Get profile data and store into $_SESSION variable
		  if(!empty($data['given_name']))
		  {
		   $_SESSION['f_name'] = $data['given_name'];
		   $f_name = $_SESSION['f_name'];
		  }

		  if(!empty($data['family_name']))
		  {
		   $_SESSION['l_name'] = $data['family_name'];
		   $l_name = $_SESSION['l_name'];
		  }

		  if(!empty($data['email']))
		  {
		   $_SESSION['user_email'] = $data['email'];
		   $email = $_SESSION['user_email'];
		  }

		  if(!empty($data['gender']))
		  {
		   $_SESSION['user_gender'] = $data['gender'];
		  }

		  if(!empty($data['picture']))
		  {
		   $_SESSION['user_image'] = $data['picture'];
		   $u_image=$_SESSION['user_image'];
		  }
	}
}

//This is for check user has login into system by using Google account, if User not login into system then it will execute if block of code and make code for display Login link for Login using Google account.

if(!isset($_SESSION['access_token']))
{
 //Create a URL to obtain user authorization
 $login_button = '<a href="'.$google_client->createAuthUrl().'" style="text-decoration: none;"><button id="signup-by-mail" class="btn btn-default btn-lg" name="signup_mail" style="width: 60%;border-radius: 30px;background-color: #white;border: 1.5px solid plum;color: plum;">Signup with Gmail</button></a>';
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign Up With Gmail</title>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
	body{
		overflow-x: hidden;
	}
	.main-content{
		width: 50%;
		height: 40%;
		margin: 10px auto;
		background-color: white;
		border: 2px solid #DDA0DD;
		padding: 40px 50px;
	}
	.header{
		border: 0px solid black;
		margin-bottom: 5px;
	}
	.well{
		background-color: #DDA0DD;
	}
	#pannel{
		border: none;
	}
	#def-pass{
		border: 1px solid black;
		border-radius:10px;
		padding:4px 6px;
	}
</style>
<body>
<div class="row">
	<div class="col-sm-12">
		<div class="well">
			<center><h1 style="color: white;">Signup with Gmail</h1></center>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="main-content">
			<div class="header">
				<h3 style="text-align: center;"><strong>Signup using Google Account</strong></h3><br/>
				<h4 style="text-align: left;">Default Password: <strong id="def-pass">123456789</strong></h4>
			</div>
			<br />

			<div class="panel panel-default" id="pannel">
			<?php
				if($login_button == ''){
					$_SESSION['user_email'] = $email;

					$check_email = $con->query("select * from users where user_email='$email'");
					// echo $check_email->num_rows;
					if($check_email->num_rows == 0){

							$newgid = sprintf('%05d',rand(0,999999));
							$username = strtolower($f_name . "_" . $l_name . "_" . $newgid);
							$sql = "insert into users (`f_name`, `l_name`, `user_name`, `describe_user`, `relationship`, `user_pass`, `user_email`, `user_country`, `user_gender`, `user_birthday`, `user_image`, `user_cover`, `user_reg_date`, `status`, `recovery_account`, `title`, `num_post`, `num_ans`, `position`, `pos_status`, `block_status`) values ('$f_name','$l_name','$username','Hello World! Hear my words.','...','123456789','$email','Vietnam','Other','1-1-1999','user_pic_4.jpg','cover.jpg',NOW(),'verified','UDPT-16','Normal',0,0,'Member',0,0)";
							$run = mysqli_query($con,$sql);
							// echo $sql;
							// }
							// echo "sucess";

							// echo '<div class="panel-heading">Welcome User</div><div class="panel-body">';
							// echo '<img src="'.$_SESSION["user_image"].'" class="img-responsive img-circle img-thumbnail" />';
							// echo '<h3><b>Name :</b> '.$_SESSION['f_name'].' '.$_SESSION['l_name'].'</h3>';
							// echo '<h3><b>Email :</b> '.$_SESSION['user_email'].'</h3>';
							// echo '<h3><b>Gender :</b> '.$_SESSION['user_gender'].'</h3>';
							// echo '<h3><a href="logout.php">Logout</h3></div>';
							echo "<script>alert('You have create an account with your gmail. Please login to continue. Your email is '.$email.'. Your password is 123456789.')</script>";
					}
					echo "<script>alert('You have already signup by '.$email.'. Please login to continue.')</script>";
					// echo "<script>window.open('localhost/social_network_mvc/?controller=homeController&action=home','_self')</script>";
					header('location: http://localhost/social_network_mvc/user/?controller=userController&action=login_view');
				}
				else{
					echo '<div align="center">'.$login_button . '</div>';
				} ?>
			</div>
		</div> 
	</div>
</div>
</body>
</html>