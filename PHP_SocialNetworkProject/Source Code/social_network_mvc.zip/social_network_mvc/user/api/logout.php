<?php
session_start();

include('config/config.php');

unset($_SESSION['access_token']);
//Reset OAuth access token
$google_client->revokeToken();

//Destroy entire session data.
session_destroy();

header("location: http://localhost/social_network_mvc/");
?>

