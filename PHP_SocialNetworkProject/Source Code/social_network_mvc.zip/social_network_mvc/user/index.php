<?php

	$action = $_GET['action'];
	$controller = $_GET['controller'];

	require_once('app/controllers/'.$controller.'.php');

	$controller = new $controller();

	$controller->$action();

?>
