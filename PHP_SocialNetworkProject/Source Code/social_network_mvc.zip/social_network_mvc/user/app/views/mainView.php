<?php 

class mainView
{
    public function main()
    {
    	require_once('public/template/main/main.php');
    }

    public function header($user_id)
    {
        require_once('public/template/main/header.php');
    }

    public function home($cats,$user_id)
    {
        require_once('public/template/main/home.php');
    }

    public function chatbot()
    {
        require_once('public/template/main/chatbot.php');
    }
}
?>