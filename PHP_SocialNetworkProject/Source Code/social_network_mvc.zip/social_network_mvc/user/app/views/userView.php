<?php

class userView
{
    public function login()
    {
    	require_once('public/template/user/login.php');
    }

    public function signup()
    {
        require_once('public/template/user/signup.php');
    }

    public function edit_account($user_id, $user_name, $first_name, $last_name, $describe_user, $relationship_status, $user_pass, $user_email, $user_country, $user_gender, $user_birthday, $recovery_account)
    {
        require_once('public/template/user/edit_account.php');
    }

    public function recovery_account()
    {
        require_once('public/template/user/recovery_account.php');
    }

    public function rank()
    {
        require_once('public/template/user/ranking.php');
    }

    public function rank_detail($user_name, $user_id, $user_image, $title, $scores, $rank)
    {
        require('public/template/user/ranking_detail.php');
    }

    public function profile($user_id, $user_name, $first_name, $last_name, $describe_user, $relationship_status, $user_pass, $user_email, $user_country, $user_gender, $user_birthday, $user_image, $user_cover, $recovery_account, $register_date, $status, $title, $num_post, $num_ans, $position, $pos_status, $block_status)
    {
        require_once('public/template/user/profile.php');
    }

    public function find_people()
    {
        require('public/template/user/find_people.php');
    }

    public function find_people_api()
    {
        require('public/template/user/find_people_api.php');
    }

    public function find_user_profile($user_id, $user_name, $first_name, $last_name, $describe_user, $relationship_status, $user_country, $user_gender, $user_birthday, $user_image, $user_cover, $register_date, $title, $num_post, $num_ans, $position)
    {
        require_once('public/template/user/find_user_profile.php');
    }

    // public function find_user_profile($id, $name, $f_name, $l_name, $describe_user, $relationship, $country, $gender, $birthday, $image, $register_date, $title, $num_post, $num_ans, $position)
    // {
    //     require_once('public/template/user/find_user_profile.php');
    // }

    public function forgot_password()
    {
        require('public/template/user/forgot_password.php');
    }

    // public function mess_profile($user_id,$user_name,$f_name,$l_name,$des_user,$user_gender,$title,$position)
    // {
    //     require('public/template/user/mess_profile.php');
    // }

    public function messages()
    {
        require('public/template/user/messages.php');
    }

    public function signup_by_gmail()
    {
        require_once('api/signup_gmail.php');
    }

}

?>