<?php


class postView
{
    public function get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id)
    {
        require('public/template/post/get_posts.php');
    }

    public function get_posts_profile($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id)
    {
        require('public/template/post/get_posts_profile.php');
    }

    public function post_detail($post_id,$user_id,$user_name,$user_image,$post_date,$cat_name,$content,$c_rate5,$c_rate4,$c_rate3,$c_rate2,$c_rate1,$c_like)
    {
    	require_once('public/template/post/post_detail.php');
    }

    public function report_post($user_image,$user_id,$user_name,$post_date,$cat_name,$content)
    {
        require_once('public/template/post/report.php');
    }

    public function search_post()
    {
        require_once('public/template/post/search_post.php');
    }

    public function my_posts()
    {
        require_once('public/template/post/my_posts.php');
    }

    public function edit_post($post,$content,$cats,$post_cat,$post_cat_name)
    {
        require_once('public/template/post/edit_post.php');
    }

    public function answers($post_id)
    {
        require_once('public/template/post/answers.php');
    }

    public function search_hashtag($hashtag)
    {
        require_once('public/template/post/hashtag.php');
    }

    // public function notifyPost($status)
    // {
    // 	if ($status) {
    // 		echo "insert success, <a href='?action=get'>click here</a>";
    // 	}else{
    // 		echo "insert fail";
    // 	}
    // }
}

?>