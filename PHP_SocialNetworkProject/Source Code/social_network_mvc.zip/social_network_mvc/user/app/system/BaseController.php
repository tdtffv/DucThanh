<?php

class BaseController
{
    public function require_model($model_name)
    {
    	require_once('app/models/'.$model_name.'.php');
        $model_name = new $model_name();
        return $model_name;
    }

    public function require_view($view_name)
    {
    	require_once('app/views/'.$view_name.'.php');
        $view_name = new $view_name();
        return $view_name;
    }
} 
?>