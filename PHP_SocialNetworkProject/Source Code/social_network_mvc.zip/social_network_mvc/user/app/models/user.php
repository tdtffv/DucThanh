<?php

require_once('app/system/BaseModel.php');

class user extends BaseModel
{
	public function login($email,$pass)
    {
        $con = $this->connect_dtb();
    	
        $select_user = "select * from users where user_email='$email' AND user_pass='$pass' AND status='verified'";
		$res = $con->query($select_user);

		if($res->num_rows == 1){
			$_SESSION['user_email'] = $email;

			echo "<script>window.open('?controller=homeController&action=home','_self')</script>";
		}else{
			echo"<script>alert('Your Email or Password is incorrect!')</script>";
		}
    }

    public function check_email($email)
    {
    	$con = $this->connect_dtb();

    	$check_email = "select * from users where user_email='$email'";
    	$res = $con->query($check_email);

		if($res->num_rows == 1){
			echo "<script>alert('Email already exist. Please try using another email!')</script>";
			echo "<script>window.open('signup.php', '_self')</script>";
			exit();
		}
    }

    public function check_pass($pass,$repass)
    {
        $con = $this->connect_dtb();

        if(strlen($pass) < 8){
            echo"<script>alert('Password should be minimum 8 characters!')</script>";
            exit();
        }else {
            if($repass != $pass){
                echo"<script>alert('Your password did not match! Please try again.')</script>";
                exit();
            }   
        }
    }

    public function signup($data)
    {
    	
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
        	$sql_k[] = $key;
        	$sql_v[] = $value;
        }
    	
        $insert = "insert into users(".implode(',', $sql_k).",user_reg_date) values ('".implode("','", $sql_v)."',NOW())";
        // echo $insert;
		$res = $con->query($insert);
		return $res;
    }

    public function get_user($user)
    {
    	$con = $this->connect_dtb();

    	$get_user = "select * from users where user_email='$user' AND status='verified'"; 
		$run_user = $con->query($get_user);
		return $row = mysqli_fetch_array($run_user);
    }

    public function get_user_by_id($user_id)
    {
    	$con = $this->connect_dtb();

    	$get_user = "select * from users where user_id='$user_id' AND status='verified'"; 
		$run_user = $con->query($get_user);
		return $row = mysqli_fetch_array($run_user);
    }

    public function update_num_post_ans($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update users set ".implode(',', $val)." where ".implode("' and '", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

    public function get_ranking($user_id)
    {
    	$con = $this->connect_dtb();

    	$get_ranking = "select * from ranking where month = month(NOW()) and year = year(NOW()) and user_id = $user_id"; 
		$run_ranking = $con->query($get_ranking);

		return $row = $run_ranking->num_rows;
    }

    public function get_user_rank()
    {
        $con = $this->connect_dtb();

        $get_rank = "select r.*,u.* from users u, ranking r where u.user_id=r.user_id and u.status='verified' and month(NOW())=r.month and year(NOW())=r.year ORDER by r.scores DESC LIMIT 0, 10";

        $run_rank = $con->query($get_rank);
        $res = array();
        if($run_rank->num_rows > 0){
            while ($res = mysqli_fetch_array($run_rank)) {
                $rank[]=$res;
            }
        }
        else{
            $rank = NULL;
        }
        // print_r($rank);
        return $rank;
    }

    public function insert_ranking($data)
    {
    	
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
        	$sql_k[] = $key;
        	$sql_v[] = $value;
        }
    	
        $insert = "insert into ranking (".implode(',', $sql_k).",month,year) values ('".implode("','", $sql_v)."',month(NOW()),year(NOW()))";
        
		$res = $con->query($insert);
		return $res;
    }

    public function update_ranking($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update ranking set ".implode(',', $val)." where ".implode(" and ", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

    public function update_title($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update users set ".implode(',', $val)." where ".implode(" and ", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

    public function update_user_account($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update users set ".implode(',', $val)." where ".implode(" and ", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }
    
    public function check_pic($pic)
    {
        if($pic === ""){
            echo "<script>alert('Please Select An Image')</script>";
        }
    }

    public function get_user_ans_of_post($post_id)
    {
        $con = $this->connect_dtb();

        $sql = "select u.*, a.* from users u, answers a where a.user_ans = u.user_name and post_id='$post_id' AND u.status='verified'";

        $res = $con->query($sql);
        $user = array();
        if($res->num_rows > 0){
            while ($user = mysqli_fetch_array($res)) {
                $users[]=$user;
            }
        }else{
            $users = NULL;
        }
        // print_r($users);
        return $users;
    }

    public function search_user($search_query)
    {
        $con = $this->connect_dtb();

        $sql = "select * from users where f_name like '%$search_query%' or l_name like '%$search_query%' or user_name like '%$search_query%' AND status='verified'";

        $res = $con->query($sql);
        $user = array();
        if($res->num_rows > 0){
            while ($user = mysqli_fetch_array($res)) {
                $users[]=$user;
            }
        }else{
            $users = NULL;
        }
        // print_r($users);
        return $users;
    }

    public function get_all_users()
    {
        $con = $this->connect_dtb();

        $sql = "select * from users where status='verified'";

        $res = $con->query($sql);
        $user = array();
        if($res->num_rows > 0){
            while ($user = mysqli_fetch_array($res)) {
                $users[]=$user;
            }
        }else{
            $users = NULL;
        }
        // print_r($users);
        return $users;   
    }
    
    public function get_user_forgot_pass($user_email,$recovery_account)
    {
        $con = $this->connect_dtb();

        $get_user = "select * from users where user_email='$user_email' AND recovery_account='$recovery_account' AND status='verified'"; 
        $run = $con->query($get_user);

        return $row = $run->num_rows;
    }

    public function get_user_messages($user_to_msg,$user_from_msg)
    {
        $con = $this->connect_dtb();

        $sql = "select * from user_messages where (user_to='$user_to_msg' AND user_from='$user_from_msg') OR (user_from='$user_to_msg' AND user_to='$user_from_msg') ORDER by 1 ASC";

        $res = $con->query($sql);
        $user = array();
        if($res->num_rows > 0){
            while ($user = mysqli_fetch_array($res)) {
                $users[]=$user;
            }
        }else{
            $users = NULL;
        }
        // print_r($users);
        return $users;   
    }

    public function insert_new_messages($data)
    {    
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }
        
        $insert = "insert into user_messages(".implode(',', $sql_k).",date) values ('".implode("','", $sql_v)."',NOW())";
        // echo $insert;
        $res = $con->query($insert);
        return $res;
    }
}