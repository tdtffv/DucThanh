<?php

require_once('app/system/BaseModel.php');

class post extends BaseModel
{
    // public function get_posts()
    // {
    //     $con = $this->connect_dtb();
    // 	$res = $con->query('select * from post');
    //     $post = array();
    //     if($res->num_rows>0){
    //         while ($post = mysqli_fetch_assoc($res)) {
    //             $posts[]=$post;
    //         }
    //     }

    //     return $posts;
    // }

    public function get_num_user_posts($user_id)
    {
        $con = $this->connect_dtb();
        $user_posts = "select * from post where author='$user_id'";
        $res = $con->query($user_posts);
        $num_posts = $res->num_rows;
        
        return $num_posts;
    }

    public function add_post($data)
    {
        $con = $this->connect_dtb();        

        $sql = "insert into post (author, content, post_cat, status, post_date) values(2, '".$data['content']."', 2, 0, NOW())";
        $res = $con->query($sql);

        return $res;
    }

    public function insert_new_post($data)
    {    
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }
        
        $insert = "insert into post(".implode(',', $sql_k).",post_date) values ('".implode("','", $sql_v)."',NOW())";
        // echo $insert;
        $res = $con->query($insert);
        return $res;
    }

    public function notify_to_admin($user_name) 
    {
        $con = $this->connect_dtb();

        $to_email = 'tdtffv@gmail.com';
        $subject = 'NEW POST IN UDPT-16 WEBSITE';
        $message = $user_name.' have been insert a new post!';
        $headers = '';

        mail($to_email, $subject, $message, $headers);
    }

    public function get_posts($start_from,$per_page,$cond)
    {
        $con = $this->connect_dtb();

        if($cond == 0){
            $sql = "select * from post where status = 0 ORDER by 1 LIMIT $start_from, $per_page";
        }else{
            $sql = "select * from post where status = 0 ORDER by 1 DESC LIMIT $start_from, $per_page";
        }

        $res = $con->query($sql);
        $post = array();

        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }
        else{
            $posts = NULL;
        }

        return $posts;
    }

    public function get_post_by_id($id,$val)
    {
        $con = $this->connect_dtb();

        if($val == 0){
            $sql = "select * from post where post_id='$id' AND status = 0 ORDER by 1 DESC";
        }else if($val == 1){
            $sql = "select * from post where author='$id' AND status = 0 ORDER by 1 DESC";
        }

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }
        else{
            $posts = NULL;
        }
        // print_r($posts);
        return $posts;
    }

    public function get_num_posts()
    {
        $con = $this->connect_dtb();

        $sql = "select * from post";

        $res = $con->query($sql);
        $post = $res->num_rows;

        return $post;
    }

    public function get_rate_avg($post_id)
    {
        $con = $this->connect_dtb();
        $sql = "select avg(rate) as rate_avg from post_rate where post_id = '$post_id'";
        $res = $con->query($sql);
        $row_rateavg = mysqli_fetch_array($res);
        $rateavg = $row_rateavg['rate_avg'];
        $rateavg = intval($rateavg);

        return $rateavg;
    }

    public function get_rate_avg_sub($rateavg)
    {
        if($rateavg == 1)
        {
            $rateavg_sub = 'Very Poor';
        }else if($rateavg == 2) {
            $rateavg_sub = 'Poor';
        }else if($rateavg == 3) {
            $rateavg_sub = 'Average';
        }else if($rateavg == 4) {
            $rateavg_sub = 'Good';
        }else if($rateavg == 5) {
            $rateavg_sub = 'Excellence';
        }else{
            $rateavg_sub = 'None';
        }

        return $rateavg_sub;
    }

    public function get_ans_by_id($id,$val)
    {
        $con = $this->connect_dtb();
        
        if($val == 0){
            $sql = "select * from answers where post_id='$id' ORDER by 1 DESC";
        }else if($val == 1){
            $sql = "select * from answers where ans_id='$id' ORDER by 1 DESC";
        }

        $res = $con->query($sql);
        $ans = array();
        if($res->num_rows > 0){
            while ($ans = mysqli_fetch_array($res)) {
                $answers[]=$ans;
            }
        }
        else{
            $answers = NULL;
        }

        return $answers;
    }

    public function check_content($content)
    {
        $con = $this->connect_dtb();

        if ($content == "") {
            echo "<script>alert('Enter something first!')</script>";
            exit();
        }
        
    }

    public function check_standard($content)
    {
        $count = 0;
        $keyword = array("shit","ass","suck");

        for($i = 0; $i<count($keyword); $i++){
            if(substr_count($content, $keyword[$i]) > 0){
                $count = $count + 1;
            }
        }

        if ($count != 0) {
            $res = 1;
        }else{
            $res = 0;
        }
        // echo $res;
        return $res;
    }

    public function insert_new_ans($data)
    {    
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }
        
        $insert = "insert into answers(".implode(',', $sql_k).",ans_date) values ('".implode("','", $sql_v)."',NOW())";
        // echo $insert;
        $res = $con->query($insert);
        return $res;
    }

    public function insert_report($data)
    {    
        $con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }
        
        $insert = "insert into report(".implode(',', $sql_k).",status,rp_date) values ('".implode("','", $sql_v)."',0,NOW())";
        // echo $insert;
        $res = $con->query($insert);
        return $res;
    }
    
    public function get_post_search($word)
    {
        $con = $this->connect_dtb();

        $sql = "select p.* from post p, category c where p.post_cat=c.cat_id and (p.content like '%$word%' or c.cat_name like '%$word%' or p.hashtag like '%$word%') and p.status = 0 ORDER by 1 DESC";

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }else{
            $posts = NULL;
        }

        return $posts;
    }

    public function update_post($update_values,$update_cond)
    {
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update post set ".implode(',', $val)." where ".implode(" and ", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

    public function get_num_ans_of_post($post_id,$user_ans_name)
    {
        $con = $this->connect_dtb();

        $sql = "select * from answers where post_id='$post_id' and user_ans = '$user_ans_name'";

        $res = $con->query($sql);
        $count = $res->num_rows;
        // echo $count;
        return $count;
    }    

    public function delete($table,$del_cond)
    {
        $con = $this->connect_dtb();

        foreach ($del_cond as $value) {
            $cond[] = $value;
        }

        $sql = "delete from $table where ".implode(" and ", $cond);

        // echo $sql;
        $res = $con->query($sql);
        return $res;
    }

    public function convert_clickable_links($content)
    {
        $expression = "/#+([a-zA-Z0-9_]+)/";  
        $hashtag = preg_replace($expression, '<a href="?controller=postController&action=search_hashtag&hashtag=$1">#$1</a>', $content);
        return $hashtag;  
    }

    public function get_post_by_hashtag($tags)
    {
        $con = $this->connect_dtb();

        $sql = "select * from post where hashtag like '%$tags%' AND status = 0 ORDER by 1 DESC";

        $res = $con->query($sql);
        $post = array();
        if($res->num_rows > 0){
            while ($post = mysqli_fetch_array($res)) {
                $posts[]=$post;
            }
        }else{
            $posts = NULL;
        }

        return $posts;

    }

}
?>