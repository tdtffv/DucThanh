<?php

require_once('app/system/BaseModel.php');

class react extends BaseModel
{	
	public function get_num_like($id,$val)
	{
		$con = $this->connect_dtb();
		if($val == 0){
			$get = "select * from post_like where post_id=$id";
		}else if($val == 1){
			$get = "select * from ans_like where ans_id=$id";
		}
		$res = $con->query($get);
		$count = $res->num_rows;

		return $count;
	}

	public function get_num_rate($post_id,$rate)
	{
		$con = $this->connect_dtb();

		$get = "select * from post_rate where post_id=$post_id and rate='$rate'";
		$res = $con->query($get);
		$count = $res->num_rows;

		return $count;
	}

	public function get_user_like($user_id,$id,$val)
	{
		$con = $this->connect_dtb();
		if($val == 0){
			$get = "select * from post_like where user_like = '$user_id' and post_id=$id";
		}else if($val == 1){
			$get = "select * from ans_like where user_like = '$user_id' and ans_id=$id";
		}
		$res = $con->query($get);
		$count = $res->num_rows;
		// echo $count;
		return $count;
	}

	public function get_user_rate($user_id,$post_id)
	{
		$con = $this->connect_dtb();

		$get = "select * from post_rate where user_rate = '$user_id' and post_id=$post_id";
		
		$res = $con->query($get);
		$count = $res->num_rows;
		// echo $count;
		return $count;
	}

	public function insert_react($data,$val)
	{
		$con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }

        if($val == 0){
            $table = 'post_like';
        }else if($val == 1){
            $table = 'ans_like';
        }else if($val == 2){
            $table = 'post_rate';
        }
        
        $insert = "insert into $table(".implode(',', $sql_k).") values ('".implode("','", $sql_v)."')";
        // echo $insert;
        $res = $con->query($insert);
        return $res;
	}

	public function delete_like($data,$val)
	{
		$con = $this->connect_dtb();

        foreach ($data as $key=>$value) {
            $sql_k[] = $key;
            $sql_v[] = $value;
        }

        if($val == 0){
            $table = 'post_like';
        }else if($val == 1){
            $table = 'ans_like';
        }
        
        $delete = "delete from $table where ".implode(" and ", $sql_v);
        // echo $delete;
        $res = $con->query($delete);
        return $res;
	}

	public function update_rate($update_values,$update_cond)
    {    
        $con = $this->connect_dtb();

        foreach ($update_values as $value) {
            $val[] = $value;
        }

        foreach ($update_cond as $value) {
            $cond[] = $value;
        }
        
        $update = "update post_rate set ".implode(',', $val)." where ".implode("' and '", $cond);
        // echo $update;
        $res = $con->query($update);
        return $res;
    }

}