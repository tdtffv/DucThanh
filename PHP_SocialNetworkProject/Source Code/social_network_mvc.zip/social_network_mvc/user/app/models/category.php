<?php

require_once('app/system/BaseModel.php');

class category extends BaseModel
{	
	public function get_category()
	{
		$con = $this->connect_dtb();

		$select_cat = "select * from category ORDER by cat_name";
		$result_cat = $con->query($select_cat);
		$cat = array();

        if($result_cat->num_rows>0){
            while ($cat = mysqli_fetch_assoc($result_cat)) {
                $cats[]=$cat;
            }
        }
        // print_r($cats);
		return $cats;
	}

	public function get_category_by_id($cat_id)
	{
		$con = $this->connect_dtb();

		$select_cat = "select * from category where cat_id = '$cat_id'";
		$result_cat = $con->query($select_cat);
		$row_cat = mysqli_fetch_array($result_cat);

        $cat_name = $row_cat['cat_name'];
		
		return $cat_name;
	}
}