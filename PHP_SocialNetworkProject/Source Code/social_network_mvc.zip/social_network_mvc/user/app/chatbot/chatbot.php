<!DOCTYPE html>
<html>
<head>
    <title>Chatbot with </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/c8a118c227.js" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="chatbot.css">
</head>
<body>
    <div class="row">
        <div class="col-sm-12">
            <div class="well">
                <center><h1><strong>CHAT BOT SYSTEM</strong></h1></center>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6" id="back-grou">
            <a href="http://localhost/social_network_mvc/user/?controller=homeController&action=home">
                <button class="btn btn-default" id="back-btn" style="background-color:plum;border-radius: 10px; color: white;">< Back</button>
            </a><hr>
            <div class="title"> 
                <div class="icon">
                    <i class="fas fa-robot"></i></i>
                </div>
            </div>
            <div class="load_msg" id="scroll_messages">
                <div class="bot-inbox inbox">                
                    <div class="msg-header" id="msg-head">
                        <p>Hello there, how can I help you?<br>Example:<h6>How to insert a new post?<br>How to change cover?<br>How to change avatar?</h6></p>       
                    </div>
                </div>
            </div>
            <div class="typing-field">
                <div class="input-data">
                    <input id="data" type="text" class="form-control" placeholder="Type something here.." autocomplete="off" required>
                    <button class="btn btn-default" id="send-btn">Send</button>
                </div>
            </div>
        </div>
        <div class="col-sm-3"></div>
    </div>
    <script>
        $(document).ready(function(){
            $("#send-btn").on("click", function(){
                $value = $("#data").val();
                $msg = '<div class="user-inbox inbox"><br><div class="msg-header" id="user-msg" ><p>'+ $value +'</p></div><br></div>';
                $(".load_msg").append($msg);
                $("#data").val('');
                
                // start ajax code
                $.ajax({
                    url: 'messagesbot.php',
                    type: 'POST',
                    data: 'text='+$value,
                    success: function(result){
                        $replay = '<div class="bot-inbox inbox"><div class="msg-header" id="msg-head"><p>'+ result +'</p></div></div>';
                        $(".load_msg").append($replay);
                        // when chat goes down the scroll bar automatically comes to the bottom
                        $(".load_msg").scrollTop($(".load_msg")[0].scrollHeight);
                    }
                });
            });
        });
    </script>
</body>
</html>