<?php

require_once('app/system/BaseController.php');
session_start();

class homeController extends BaseController
{
	public function header()
    {
        $view = $this->require_view('mainView');
        
        $user = $this->require_model('user');

        $usermail = $_SESSION['user_email'];
        $row = $user->get_user($usermail);
                    
        $user_id = $row['user_id']; 
        
        $view->header($user_id);
    }

    public function home()
    {
    	$cat = $this->require_model('category');
		$cats = $cat->get_category();

    	$view = $this->require_view('mainView');
        $post_view = $this->require_view('postView');

		$user = $this->require_model('user');
		$post = $this->require_model('post');

        $usermail = $_SESSION['user_email'];
        $user_id = $user->get_user($usermail);

        $view->home($cats,$user_id);

        $per_page = 10;

        if(isset($_GET['page'])){
            $page = $_GET['page'];
        }else    
        {
            $page = 1;
        }

        $start_from = ($page - 1) * $per_page;

        if(isset($_POST['asc'])){
            $cond = 0;
        }
        else{
            $cond = 1;
        }
        $run_posts = $post->get_posts($start_from,$per_page,$cond);

        foreach($run_posts as $row_posts){

            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
            $contents = substr($row_posts['content'], 0,40);
            $post_cat = $row_posts['post_cat'];
            $post_date = $row_posts['post_date'];
            $content = $post->convert_clickable_links($contents);

            $cat_name = $cat->get_category_by_id($post_cat);

            $row_user = $user->get_user_by_id($user_id);

            $user_name = $row_user['user_name'];
            $user_image = $row_user['user_image'];

            $rateavg = $post->get_rate_avg($post_id);

            $rateavg_sub = $post->get_rate_avg_sub($rateavg);

            //now displaying posts from database

            if(strlen($content) >= 1){
                $post_view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);
            }
        }

        $total_posts = $post->get_num_posts();
        $total_pages = ceil($total_posts / $per_page);

        echo"
        <center>
        <ul class='pagination'>
            <li class='page-item'>
                <a href='?controller=homeController&action=home&page=1'>First Page</a>
            </li>
        ";

        for ($i=1; $i <= $total_pages ; $i++) { 
            echo"
            <li class='page-item'>
                <a href='?controller=homeController&action=home&page=$i'>$i</a>
            </li>";
        }

        echo"
            <li class='page-item'>
                <a href='?controller=homeController&action=home&page=$total_pages'>Last Page</a>
            </li>
        </ul>";

    }

    public function chatbot()
    {
        $view = $this->require_view('mainView');
        $view->chatbot();
    }

    // public function chatbot_reply()
    // {
    //     $bot = $this->require_model('bot');       

    //     // getting user message through ajax
    //     if (isset($_POST['text'])) {
    //         $getMesg = $_POST['text'];
    //     }
            
    //     // echo $getMesg;

    //     //checking user query to database query
    //     $check_data = $bot->check_ques($getMesg);

    //     // if user query matched to database query we'll show the reply otherwise it go to else statement
    //     if($check_data > 0){
    //         //fetching replay from the database according to the user query
    //         $get_reply = $bot->bot_reply($getMesg);
    //         foreach ($get_reply as $fetch_data) {
    //             //storing replay to a varible which we'll send to ajax
    //             $result = $fetch_data['replies'];
    //             $replay = '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-robot"></i></div><div class="msg-header"><p>'. $result .'</p></div></div>';
    //         }
    //         echo $replay;
    //     }
    //     else{
    //         echo "Sorry can't be able to understand you!";
    //     }
    // }
}