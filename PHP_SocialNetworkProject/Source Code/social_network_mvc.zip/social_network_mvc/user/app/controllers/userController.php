<?php

require_once('app/system/BaseController.php');
session_start();

class userController extends BaseController
{
	public function main()
	{
		$main = $this->require_view('mainView');
		$main->main();
	}

	public function login_view()
    {
		$user_view = $this->require_view('userView');
		$user_view->login();
    }

    public function login()
    {
		$user_view = $this->require_view('userView');
		$user_view->login();
		$user = $this->require_model('user');

		$email = $_POST['email'];
		$pass = $_POST['pass'];

		$user_login = $user->login($email,$pass);
    }

    public function signup_by_gmail()
    {
    	$user_view = $this->require_view('userView');
		$user_view->signup_by_gmail();
    }

    public function logout()
    {

		session_destroy();

		header("location:http://localhost/social_network_mvc/");
    }

    public function logout_gmail()
    {
    	include('api/config/config.php');

		unset($_SESSION['access_token']);
		//Reset OAuth access token
		$google_client->revokeToken();

		//Destroy entire session data.
		session_destroy();

		header("location:http://localhost/social_network_mvc/");
    }

   public function signup_view()
    {
		$user_view = $this->require_view('userView');
		$user_view->signup();

    }

    public function signup()
    {
		$user_view = $this->require_view('userView');
		$user_view->signup();
		$user = $this->require_model('user');

		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$pass = $_POST['u_pass'];
		$repass = $_POST['u_repass'];
		$email = $_POST['u_email'];
		$country = $_POST['u_country'];
		$gender = $_POST['u_gender'];
		$birthday = $_POST['u_birthday'];
		$status = 'verified';
		$newgid = sprintf('%05d',rand(0,999999));
		$username = strtolower($first_name . "_" . $last_name . "_" . $newgid);
		
		$check_email = $user->check_email($email,$pass,$repass);
		$check_pass = $user->check_pass($pass,$repass);

		$rand = rand(1, 3);
			if($rand == 1)
				$profile_pic = "user_pic_1.jpg";
			else if($rand == 2)
				$profile_pic = "user_pic_2.jpg";
			else if($rand == 3)
				$profile_pic = "user_pic_3.jpg";

		$data = array(
			'f_name' => $first_name,
			'l_name' => $last_name,
			'user_name' => $username,
			'describe_user' => 'Hello World! Hear my words.',
			'relationship' => '...',
			'user_pass' => $pass,
			'user_email' => $email,
			'user_country' => $country,
			'user_gender' => $gender,
			'user_birthday' => $birthday,
			'user_image' => $profile_pic,
			'user_cover' => 'cover.jpg',
			
			'status' => $status,
			'recovery_account' => 'UDPT-16',
			'title' => 'Normal',			
			'num_post' => 0,
			'num_ans' => 0,
			'position' => 'Member',
			'pos_status' => 0,
			'block_status' => 0
		);

		$res = $user->signup($data);

		if($res){
			echo "<script>alert('Success! $first_name, you are good to go.')</script>";
			echo "<script>window.open('?controller=userController&action=login_view', '_self')</script>";
		}
		else{
			echo "<script>alert('Registration failed, please try again!')</script>";
			echo "<script>window.open('?controller=userController&action=signup_view', '_self')</script>";
		}
    }

    public function edit_account_prepare()
    {
        $view = $this->require_view('userView');
        
        $user = $this->require_model('user');

        $usermail = $_SESSION['user_email'];
        $row = $user->get_user($usermail);
                    
        $user_id = $row['user_id']; 
        $user_name = $row['user_name'];
        $first_name = $row['f_name'];
        $last_name = $row['l_name'];
        $describe_user = $row['describe_user'];
        $relationship_status = $row['relationship'];
        $user_pass = $row['user_pass'];
        $user_email = $row['user_email'];
        $user_country = $row['user_country'];
        $user_gender = $row['user_gender'];
        $user_birthday = $row['user_birthday'];
        $user_image = $row['user_image'];
        $user_cover = $row['user_cover'];
        $recovery_account = $row['recovery_account'];
        $register_date = $row['user_reg_date'];
        $status = $row['status'];
        $title = $row['title'];
        $num_post = $row['num_post'];
        $num_ans = $row['num_ans'];
        $position = $row['position'];
        $pos_status = $row['pos_status'];
        $block_status= $row['block_status'];
                    
        $view->edit_account($user_id, 
        $user_name,
        $first_name,
        $last_name,
        $describe_user,
        $relationship_status,
        $user_pass,
        $user_email,
        $user_country,
        $user_gender,
        $user_birthday,
        $recovery_account);
    }

    public function edit_account()
    {
    	$user = $this->require_model('user');
    	
    	if(isset($_POST['update'])){

	    	$user_id = $_GET['u_id'];

	    	$f_name = htmlentities($_POST['f_name']);
			$l_name = htmlentities($_POST['l_name']);
			$u_name = htmlentities($_POST['u_name']);
			$describe_user = htmlentities($_POST['describe_user']);
			$relationship = htmlentities($_POST['relationship']);
			$u_pass = htmlentities($_POST['u_pass']);
			$u_email = htmlentities($_POST['u_email']);
			$u_country = htmlentities($_POST['u_country']);
			$u_gender = htmlentities($_POST['u_gender']);
			$u_birthday = htmlentities($_POST['u_birthday']);

			$up_account_val = array(
				"f_name='$f_name'",
				"l_name='$l_name'", 
				"user_name='$u_name'", 
				"describe_user='$describe_user'", 
				"relationship='$relationship'", 
				"user_pass='$u_pass'",
				"user_email='$u_email'", 
				"user_country='$u_country'", 
				"user_gender='$u_gender'", 
				"user_birthday='$u_birthday'"
			);

			$up_account_cond = array(
				"user_id='$user_id'"
			);

			$update = $user->update_user_account($up_account_val,$up_account_cond);

			if($update){
				echo "<script>alert('Your Profile Updated!')</script>";
			}
			else{
				echo "<script>alert('Something was wrong! Please try again.')</script>";
			}
			echo "<script>window.open('?controller=userController&action=edit_account_prepare&u_id=$user_id','_self')</script>";
		}
		else if (isset($_POST['sub'])) {
			$this->recovery_account();
		}

    }

    public function recovery_account()
    {
    	$user = $this->require_model('user');
    	$post = $this->require_model('post');

    	$view = $this->require_view('userView');
    	$view->recovery_account();

    	if(isset($_POST['sub'])){
    		$user_id = $_GET['u_id'];
			$r_ans = htmlentities($_POST['r_content']);

			$check_rans = $post->check_content($r_ans);

			$up_re_val = array(
				"recovery_account='$r_ans'"
			);

			$up_re_cond = array(
				"user_id='$user_id'"
			);
			
			$update = $user->update_user_account($up_re_val,$up_re_cond);
			
			if($update){
				echo "<script>alert('Your answer were saved.')</script>";
			}
			else{
				echo "<script>alert('Error! Please try again.')</script>";
			}
			echo "<script>window.open('?controller=userController&action=edit_account_prepare&u_id=$user_id','_self')</script>";
			
		}
    }

    public function ranking()
    {
    	
		$view = $this->require_view('userView');
		$r_view = $view->rank();

		$this->ranking_detail();
      	
      	echo "
	      		</table>
					</form>
				</div>
				<div class='col-sm-2'></div>
			</div>
			</body>
			</html>
      	";
    }

    public function ranking_detail()
    {
    	$user = $this->require_model('user');
    	$post = $this->require_model('post');

    	$rank = 0;
		$temp_score = 0;

		$run_rank = $user->get_user_rank();

		foreach ($run_rank as $row_rank) {
			
       	  	if($temp_score != $row_rank['scores'])
             	$rank++;
             

        	$user_name = $row_rank['user_name'];
        	$user_id = $row_rank['user_id'];
        	$user_image = $row_rank['user_image'];
			$scores = $row_rank['scores'];

			if($scores >= 50){
				$title = 'Featured';
			}else if($scores >= 30){
				$title = 'Active';
			}else{
				$title = 'Normal';
			}

			$up_title_val = array(
				"title='$title'"
			);

			$up_title_cond = array(
				"user_id='$user_id'"
			);

			$update = $user->update_ranking($up_title_val,$up_title_cond);

			$view = $this->require_view('userView');
			$rd_view = $view->rank_detail($user_name, $user_id, $user_image, $title, $scores, $rank);
	    		 
	    	$temp_score = $scores;
    	}
    }

    public function profile()
    {
    	$user = $this->require_model('user');
    	$post = $this->require_model('post');
    	$cat = $this->require_model('category');

    	$usermail = $_SESSION['user_email'];
        $row = $user->get_user($usermail);
                    
        $user_id = $row['user_id']; 
        $user_name = $row['user_name'];
        $first_name = $row['f_name'];
        $last_name = $row['l_name'];
        $describe_user = $row['describe_user'];
        $relationship_status = $row['relationship'];
        $user_pass = $row['user_pass'];
        $user_email = $row['user_email'];
        $user_country = $row['user_country'];
        $user_gender = $row['user_gender'];
        $user_birthday = $row['user_birthday'];
        $user_image = $row['user_image'];
        $user_cover = $row['user_cover'];
        $recovery_account = $row['recovery_account'];
        $register_date = $row['user_reg_date'];
        $status = $row['status'];
        $title = $row['title'];
        $num_post = $row['num_post'];
        $num_ans = $row['num_ans'];
        $position = $row['position'];
        $pos_status = $row['pos_status'];
        $block_status= $row['block_status'];

    	$view = $this->require_view('userView');
		$view->profile($user_id, $user_name, $first_name, $last_name, $describe_user, $relationship_status, $user_pass, $user_email, $user_country, $user_gender, $user_birthday, $user_image, $user_cover, $recovery_account, $register_date, $status, $title, $num_post, $num_ans, $position, $pos_status, $block_status);

		if(isset($_POST['updatecover'])){

			$u_cover = $_FILES['u_cover']['name'];
			$image_tmp = $_FILES['u_cover']['tmp_name'];
			$random_number = rand(1,100);

			$check_pic = $user->check_pic($u_cover);

			move_uploaded_file($image_tmp, "public/images/cover/$u_cover.$random_number");
				
			$up_cover_val = array(
				"user_cover='$u_cover.$random_number'"
			);

			$up_cover_cond = array(
				"user_id='$user_id'"
			);			

			$update = $user->update_user_account($up_cover_val,$up_cover_cond);

			if($update){
				echo "<script>alert('Your Cover Updated')</script>";
			}else{
				echo "<script>alert('Error! Please try again!')</script>";
			}
			echo "<script>window.open('?controller=userController&action=profile&u_id=$user_id' , '_self')</script>";
		}
		else if(isset($_POST['updateavatar'])){

			$u_image = $_FILES['u_image']['name'];
			$image_tmp = $_FILES['u_image']['tmp_name'];
			$random_number = rand(1,100);

			$check_pic = $user->check_pic($u_image);

			move_uploaded_file($image_tmp, "public/images/user/$u_image.$random_number");

			$up_avatar_val = array(
				"user_image='$u_image.$random_number'"
			);

			$up_avatar_cond = array(
				"user_id='$user_id'"
			);			

			$update = $user->update_user_account($up_avatar_val,$up_avatar_cond);

			if($update){
				echo "<script>alert('Your Avatar Updated')</script>";
			}else{
				echo "<script>alert('Error! Please try again!')</script>";
			}
			echo "<script>window.open('?controller=userController&action=profile&u_id=$user_id' , '_self')</script>";
		}

		$run_posts = $post->get_post_by_id($user_id,1);
		if($run_posts != NULL){
			foreach ($run_posts as $row_posts) {
			    
				$post_id = $row_posts['post_id'];
				$user_id = $row_posts['author'];
				$content = $post->convert_clickable_links($row_posts['content']);
				$post_cat = $row_posts['post_cat'];
				$post_date = $row_posts['post_date'];

				$cat_name = $cat->get_category_by_id($post_cat);

				$row_user = $user->get_user_by_id($user_id);

				$user_name = $row_user['user_name'];
				$user_image = $row_user['user_image'];

				$rateavg = $post->get_rate_avg($post_id);

	            $rateavg_sub = $post->get_rate_avg_sub($rateavg);

				if(strlen($content) >= 1){
				echo"
				<div id='own_posts'>
					<div class='row'>
						<div class='col-sm-1'></div>
						<div id='posts' class='col-sm-11' style='border:2px solid black; border-radius:20px; padding: 20px;'>
							<div class='row'>
								<div class='col-sm-2'>
								<p><img src='public/images/user/$user_image' class='img-circle' width='80px' height='80px'></p>
								</div>
								<div class='col-sm-6'>
									<h3><a style='text-decoration:none; cursor:pointer; color #3897f0;' href='?controller=userController&action=profile&u_id=$user_id'>$user_name</a></h3>
									<h4><small style='color:black;'>Updated a post on <strong>$post_date</strong></small></h4>
								</div>
								<div class='col-sm-4'>
									<h4 style='color: black; float: right; color: grey;'><strong>$cat_name</strong></h4>
								</div>
							</div>
							<div class='row'>
								<div class='col-sm-8'>
									<h3><p>$content</p></h3>
								</div>
							</div>
							<h5>Avergare Rate: <strong id='rate-avg' style='border: 1px solid black;border-radius:10px;padding:4px 6px;'>$rateavg_sub</strong></h5>
							<a href='?controller=postController&action=delete_post&post_id=$post_id' style='float:right;'>
								<button class='btn btn-danger'>Delete</button>
							</a>
							<a href='?controller=postController&action=edit_post&post_id=$post_id' style='float:right;'>
								<button class='btn btn-outline-info'>Edit</button>
							</a>
							<a href='?controller=postController&action=post_detail&post_id=$post_id' style='float:right;'>
								<button class='btn btn-info'>View</button>
							</a>
							</div>
						</div><br><br>
						";
				}
			}
			echo "
					</div>
					<div class='col-sm-2'></div>
				</div>
				</body>
				</html>
			";
		}
		else{
			echo "<hr/><h4><center><strong><i>There is no post yet</i></strong></center></h4>";
		}
	}

	public function find_people()
	{
		$user = $this->require_model('user');

		$view = $this->require_view('userView');
		$view->find_people();

		if (isset($_GET['search_user_btn'])) {
			$search_query = htmlentities($_GET['search_user']);
			$get_user = $user->search_user($search_query);
		}
		else{
			$get_user = $user->get_all_users();
		}
		if($get_user != NULL)
		{		
			foreach ($get_user as $row_user) {
		    
				$user_id = $row_user['user_id'];
				$f_name = $row_user['f_name'];
				$l_name = $row_user['l_name'];
				$username = $row_user['user_name'];
				$user_image = $row_user['user_image'];

				echo "
				<div class='row'>
					<div class='col-sm-3'></div>
					<div class='col-sm-5'>
						<div class='row' id='find_people'>
							<div class='col-sm-4'>
								<a href='?controller=userController&action=find_user_profile&u_id=$user_id'>
									<img src='public/images/user/$user_image' class='img-circle' width=120px height=120px title='$username' style='float:left; margin:1px;'/>
								</a>
							</div><br><br>
							<div class='col-sm-6'>
								<a style='text-decoration: none; cursor:pointer; color:#3897F0;' href='?controller=userController&action=find_user_profile&u_id=$user_id'>
									<strong><h3>$f_name $l_name</h3></strong>
								</a>
							</div>
							<div class='col-sm-6'></div>
						</div>
					</div>
					<div class='col-sm-12'></div>
				</div><br>
				";
			}
		}else{
			echo "<hr><hr><center><h2>Sorry! We can't find any user like <strong><i>$search_query</i></strong></h2></center>";
		}
	}

	// public function find_people_api()
	// {
	// 	$user = $this->require_model('user');

	// 	// if (isset($_GET['search_user_btn'])) {
	// 		$search_query = ($_POST['search_user']);
	// 		$get_user = $user->search_user($search_query);
	// 		echo json_encode($get_user);
	// 	// }
	// 	// else{
	// 	// 	$get_user = $user->get_all_users();
	// 	// }
		
	// }

	// public function find_user_profile()
	// {
	// 	$user = $this->require_model('user');

	// 	if(isset($_GET['u_id'])){

	// 		$user_id = $_GET['u_id'];
	// 		$row = $user->get_user_by_id($user_id);

	// 		$id = $row['user_id'];
	// 		$name = $row['user_name'];
	// 		$f_name = $row['f_name'];
	// 		$l_name = $row['l_name'];
	// 		$describe_user = $row['describe_user'];
	// 		$relationship = $row['relationship'];
	// 		$country = $row['user_country'];
	// 		$gender = $row['user_gender'];
	// 		$birthday = $row['user_birthday'];
	// 		$image = $row['user_image'];
	// 		$cover = $row['user_cover'];
	// 		$register_date = $row['user_reg_date'];
	// 		$title = $row['title'];
	// 		$num_post = $row['num_post'];
	// 		$num_ans = $row['num_ans'];
	// 		$position = $row['position'];

	// 		$user_mail = $_SESSION['user_email'];
	// 		$row = $user->get_user($user_mail);

	// 		$userown_id = $row['user_id'];

	// 		$view = $this->require_view('userView');
	// 		$view->find_user_profile($id, $name, $f_name, $l_name, $describe_user, $relationship, $country, $gender, $birthday, $image, $cover, $register_date, $title, $num_post, $num_ans, $position);

	// 		if($user_id == $userown_id){
	// 			echo"<a href='?controller=userController&action=edit_account_prepare&u_id=$userown_id' class='btn btn-info' id='edit-btn' />Edit Profile</a><br><br><br>";
	// 		}

	// 		echo"
	// 			</div>
	// 		</center>
	// 		<div class='col-sm-8'>
	// 			<center><h1>Posts</h1></center><br><br>

	// 		";

	// 		$this->find_user_posts();

	// 		echo"
	// 			</body>
	// 			</html>
	// 		";
				
	// 	}
	// }

	public function find_user_profile()
	{
		$user = $this->require_model('user');
		$post = $this->require_model('post');
		$cat = $this->require_model('category');

		if(isset($_GET['u_id'])){

			$user_id = $_GET['u_id'];
			$row = $user->get_user_by_id($user_id);

			$id = $row['user_id'];
			$name = $row['user_name'];
			$f_name = $row['f_name'];
			$l_name = $row['l_name'];
			$describe_user = $row['describe_user'];
			$relationship = $row['relationship'];
			$country = $row['user_country'];
			$gender = $row['user_gender'];
			$birthday = $row['user_birthday'];
			$image = $row['user_image'];
			$cover = $row['user_cover'];
			$register_date = $row['user_reg_date'];
			$title = $row['title'];
			$num_post = $row['num_post'];
			$num_ans = $row['num_ans'];
			$position = $row['position'];

			$user_mail = $_SESSION['user_email'];
			$row = $user->get_user($user_mail);

			$userown_id = $row['user_id'];

			$view = $this->require_view('userView');
			$view->find_user_profile($id, $name, $f_name, $l_name, $describe_user, $relationship, $country, $gender, $birthday, $image, $cover, $register_date, $title, $num_post, $num_ans, $position);

			if($user_id == $userown_id){
				header("location: ?controller=userController&action=profile");
			}else{

				$run_posts = $post->get_post_by_id($user_id,1);

				foreach ($run_posts as $row_posts) {
			    
				$post_id = $row_posts['post_id'];
				$user_id = $row_posts['author'];
				$content = $post->convert_clickable_links($row_posts['content']);
				$post_cat = $row_posts['post_cat'];
				$post_date = $row_posts['post_date'];

				$cat_name = $cat->get_category_by_id($post_cat);

				$row_user = $user->get_user_by_id($user_id);

				$user_name = $row_user['user_name'];
				$user_image = $row_user['user_image'];

				$rateavg = $post->get_rate_avg($post_id);

	            $rateavg_sub = $post->get_rate_avg_sub($rateavg);

				if(strlen($content) >= 1){
				echo"
				<div id='own_posts'>
					<div class='row'>
						<div class='col-sm-1'></div>
						<div id='posts' class='col-sm-11' style='border:2px solid black; border-radius:20px; padding: 20px;'>
							<div class='row'>
								<div class='col-sm-2'>
								<p><img src='public/images/user/$user_image' class='img-circle' width='80px' height='80px'></p>
								</div>
								<div class='col-sm-6'>
									<h3><a style='text-decoration:none; cursor:pointer; color #3897f0;' href='?controller=userController&action=profile&u_id=$user_id'>$user_name</a></h3>
									<h4><small style='color:black;'>Updated a post on <strong>$post_date</strong></small></h4>
								</div>
								<div class='col-sm-4'>
									<h4 style='color: black; float: right; color: grey;'><strong>$cat_name</strong></h4>
								</div>
							</div>
							<div class='row'>
								<div class='col-sm-2'></div>
								<div class='col-sm-8'>
									<h3><p>$content</p></h3>
								</div>
							</div>
							<h5>Avergare Rate: <strong id='rate-avg' style='border: 1px solid black;border-radius:10px;padding:4px 6px;'>$rateavg_sub</strong></h5>
							<a href='?controller=postController&action=report&post_id=$post_id' style='float:right;'>
								<button class='btn btn-danger'>Report</button>
							</a>
							<a href='?controller=postController&action=post_detail&post_id=$post_id' style='float:right;'>
								<button class='btn btn-info'>View</button>
							</a>
							</div>
						</div><br><br>
						";
					}
				}
				echo "
						</div>
						<div class='col-sm-2'></div>
					</div>
					</body>
					</html>
				";
			}
		}
	}

	public function find_user_posts()
	{
		$user = $this->require_model('user');
		$post = $this->require_model('post');
		$cat = $this->require_model('category');

		if (isset($_GET['u_id'])){
			$user_id = $_GET['u_id'];
		}

		$run_post = $post->get_post_by_id($user_id,1);

			foreach ($run_post as $row_post) {
			    
				$post_id = $row_post['post_id'];
				$user_id = $row_post['author'];
				$content = $post->convert_clickable_links($row_post['content']);
				$post_cat = $row_post['post_cat'];
				$post_date = $row_post['post_date'];

				$cat_name = $cat->get_category_by_id($post_cat);

				$row_user = $user->get_user_by_id($user_id);

				$name = $row_user['user_name'];
				$f_name = $row_user['f_name'];
				$l_name = $row_user['l_name'];
				$image = $row_user['user_image'];

				$rateavg = $post->get_rate_avg($post_id);

        	    $rateavg_sub = $post->get_rate_avg_sub($rateavg);

				if(strlen($content) >= 1){
					echo "
						<div id='own_post' class='own_posts'>
							<div class='row'>
								<div class='col-sm-2'>
									<p><img src='public/images/user/$image' class='img-circle' width='100px' height='100px'></p>
								</div>
								<div class='col-sm-6'>
									<h3><a href='?controller=userController&action=find_user_profile&u_id=$user_id'>$name</a></h3>
									<h4><small id='post_date' style='color: black;'>Update a post on <strong>$post_date</strong></small></h4>
								</div>
								<div class='col-sm-4'>
								<h4 style='color: black; float: right; color: grey;'><strong>$cat_name</strong></h4>
							</div>
							</div>
							<div class='row'>
								<div class='col-sm-12'>
									<h3><p>$content</p></h3>
								</div>
							</div><br>
							<h5>Avergare Rate: <strong id='rate-avg' style='border: 1px solid black;border-radius:10px;padding:4px 6px;'>$rateavg_sub</strong></h5>
							<a href='?controller=postController&action=report&post_id=$post_id' style='float:right;'><button class='btn btn-danger'>Report</button></a>
							<a href='?controller=postController&action=post_detail&post_id=$post_id' style='float:right;'><button class='btn btn-info'>View</button></a><br>
						</div><br><br>
					";
				}
			}
			echo"
						</div>
					</div>
				</div>
				";
		
	}

	public function forgot_password()
	{
		$user = $this->require_model('user');
		$post = $this->require_model('post');
		$cat = $this->require_model('category');

		$view = $this->require_view('userView');
		$view->forgot_password();

		if (isset($_POST['submit'])) {

			$email = htmlentities($_POST['email']);
			$recovery_account = htmlentities($_POST['recovery_account']);

			$check_user = $user->get_user_forgot_pass($email,$recovery_account);

			if($check_user == 1){
				$_SESSION['user_email'] = $email;

				$pass = htmlentities($_POST['pass']);
				$repass = htmlentities($_POST['repass']);

				$check_pass = $user->check_pass($pass,$repass);

				$up_pass_val = array(
					"user_pass='$pass'"
				);

				$up_pass_cond = array(
					"user_email='$email'"
				);				

				$update = $user->update_user_account($up_pass_val,$up_pass_cond);

				if($update){
					echo "<script>alert('Your password is changed!')</script>";
					echo "<script>window.open('?controller=userController&action=login_view', '_self')</script>";
				}
			}
			else{
				echo"<script>alert('Your email or answer is incorrect!')</script>";
			}
		}
	}

	public function messages()
	{
		$user = $this->require_model('user');
		$post = $this->require_model('post');
		$cat = $this->require_model('category');

		$view = $this->require_view('userView');
		
		// $view->mess_profile($user_id,$user_name,$f_name,$l_name,$des_user,$user_gender,$title,$position);
		$view->messages();

		if(isset($_GET['u_id']) && (int)$_GET['u_id']) {
			
			$get_id = $_GET['u_id'];
			
			$row_user = $user->get_user_by_id($get_id);

			$user_to_msg = $row_user['user_id'];
			$user_to_name = $row_user['user_name'];
		}

		$usermail = $_SESSION['user_email'];
		$row = $user->get_user($usermail);

		$user_from_msg = $row['user_id'];
		$user_from_name = $row['user_name'];

		echo '<div class="col-sm-3" id="select_user">';

		$run_user = $user->get_all_users();
		foreach ($run_user as $row_user) {
		    
			$user_id = $row_user['user_id'];
			$user_name = $row_user['user_name'];
			$first_name = $row_user['f_name'];
			$last_name = $row_user['l_name'];
			$user_image = $row_user['user_image'];

			echo"
				<div class='container-fluid'>
					<a style='text-decoration: none; cursor:  pointer; color:#3897F0;' href='?controller=userController&action=messages&u_id=$user_id'>
						<img class='img-circle' src='public/images/user/$user_image' width='90px' height = '80px' title='$user_name'> <strong>&nbsp $first_name $last_name </strong><br><br>
					</a>
				</div>
			";
		}

		echo '</div>
		<div class="col-sm-6">
			<div class="load_msg" id="scroll_messages">';
				
		if(isset($_GET['u_id']) && (int)$_GET['u_id']) {

			$run_msg = $user->get_user_messages($user_to_msg,$user_from_msg);
			if($run_msg != NULL){
			foreach ($run_msg as $row_msg){

				$user_to = $row_msg['user_to'];
				$user_from = $row_msg['user_from'];
				$msg_body = $row_msg['mes_body'];
				$msg_date = $row_msg['date'];
				
				echo'
				<div id="loaded_msg">
					<p>';
					if($user_from == $user_from_msg AND $user_to == $user_to_msg) {
				
						echo "<div class='message' id='blue' data-toggle='tooltip' title='$msg_date'>$msg_body</div><br><br><br>";
					}
					else if($user_from == $user_to_msg AND $user_to == $user_from_msg) {
						
						echo "<div class='message' id='green' data-toggle='tooltip' title='$msg_date'>$msg_body</div><br><br><br>";
					}
					echo'</p>	
				</div>';
				
			}
		}
		}
		echo'
		</div>';
			
		if(isset($_GET['u_id'])){
			$u_id = $_GET['u_id'];
			if($u_id == "new") {
				echo'

				<form>
					<center><h3>Select Someone to start conversation</h3></center>
					<textarea disabled class="form-control" placeholder="Enter your Messages"></textarea>
					<input type="submit" class="btn btn-default" disabled value="Send">
				</form><br><br>
				';
			}
			else{
				echo'
					<form action="" method="POST">
						<textarea class="form-control" placeholder="Enter your Messages" name="msg_box" id="message_textarea"></textarea>
						<input type="submit" name="send_msg" id="btn-msg" value="Send">
					</form><br><br>	
				';				
			}
		}
			
		if(isset($_POST['send_msg'])){
			$msg = htmlentities($_POST['msg_box']);

			if($msg ==""){
				echo"<h4 style='color:red; text-align: center;'>Nothing to send, please try again!</h4>";
			}
			else{
				$data = array(
					"user_to" => $user_to_msg,
					"user_from" => $user_from_msg,
					"mes_body" => $msg
				);

				$insert = $user->insert_new_messages($data);

			}
		}
		echo'
		</div>
		<div class="col-sm-3">';
		
		if(isset($_GET['u_id']) && (int)$_GET['u_id']) {
			
				$get_id = $_GET['u_id'];	

			$row = $user->get_user_by_id($get_id);

			$user_id = $row['user_id'];
			$user_name = $row['user_name'];
			$user_image = $row['user_image'];
			$f_name = $row['f_name'];
			$l_name = $row['l_name'];
			$describe_user = $row['describe_user'];
			$user_gender = $row['user_gender'];
			$title = $row['title'];	

			echo"
					<div class='row'>
						<div class='col-sm-2'>
						</div>
						<center>
						<div style='background-color: #ffedfa;' class='col-sm-9'>
								<h2>Information About</h2>
								<img class='img-circle' src='public/images/user/$user_image' width='150' height='150'>
								<br><br>
								<ul class='list-group'>
									<li class='list-group-item' title='User status'><strong>$f_name $l_name</strong></li>

									<li class='list-group-item' title='User status'><strong style='color: grey;'>$describe_user</strong></li>

									<li class='list-group-item' title='Gender'>$user_gender</li>

									<li class='list-group-item' title='title'>Title: $title</li>
								</ul>
						</div>
							<div class='col-sm-1'>

							</div>
						</div>
					";

		}

		

	}
}

?>