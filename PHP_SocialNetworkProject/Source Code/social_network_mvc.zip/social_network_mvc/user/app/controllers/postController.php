<?php 
session_start();
require_once('app/system/BaseController.php');

class postController extends BaseController
{
    public function insert_new_Post()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');

        $usermail = $_SESSION['user_email'];
        $row = $user->get_user($usermail);
                    
        $user_id = $row['user_id'];

        $content = htmlentities($_POST['content']);
        $post_cat = $_POST['cat_id'];

        $status = $post->check_standard($content);

        $message = strip_tags(trim($content));
        //get hashtag from message
        $hashtag = $this->gethashtags($message);

        if(strlen($content) > 500){
            echo "<script>alert('Please Use 500 or less than 500 words!')</script>";
            echo "<script>window.open('?controller=homeController&action=home', '_self')</script>";
        }else{
            if(strlen($content) >= 1){

                $data = array(
                    'author' => $user_id,
                    'content' => $content,
                    'post_cat' => $post_cat,
                    'hashtag' => $hashtag,
                    'status' => $status
                );

                $post = $this->require_model('post');
                $insert = $post->insert_new_post($data);

                if($insert){
                    if($status == 0){
                        $update_values = array(
                            'num_post = num_post+1'
                        );

                        $update_cond = array(
                            "user_id = '$user_id'"
                        );

                        $user = $this->require_model('user');
                        $update = $user->update_num_post_ans($update_values,$update_cond);

                        $get_rank = $user->get_ranking($user_id);

                        if($get_rank === 0){

                            $data_rank = array(
                                'user_id' => $user_id, 
                                'scores' => 5, 
                                'numpost_thismonth' => 1, 
                                'numans_thismonth' => 0
                            );

                            $insert_rank = $user->insert_ranking($data_rank);

                        }else if($get_rank != 0){

                            $up_rank_val = array(
                                'numpost_thismonth = numpost_thismonth +1', 
                                'scores = scores+5'
                            );

                            $up_rank_cond = array(
                                "user_id = '$user_id'",
                                "month = month(NOW())",
                                "year = year(NOW())"
                            );

                            $update_rank = $user->update_ranking($up_rank_val,$up_rank_cond);
                        }
                        echo "<script>alert('Your Post updated a moment ago!')</script>";
                    }else if($status == 1){
                        echo "<script>alert('Your post has been sent to the admin for approval due to some wording that violates community standards!')</script>";
                    }
                }
                
                echo "<script>window.open('?controller=homeController&action=home', '_self')</script>";
            }
            else{
                $check_content = $post->check_content($content);
            }
        }
    }

    public function post_detail()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $cat = $this->require_model('category');
        $react = $this->require_model('react');

        $view = $this->require_view('postView');

        $get_id = $_GET['post_id'];
        
        $run_posts = $post->get_post_by_id($get_id,0);
        foreach ($run_posts as $row_posts) {
            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
            $content = $post->convert_clickable_links($row_posts['content']);
            $post_cat = $row_posts['post_cat'];
            $post_date = $row_posts['post_date'];
        }

        $cat_name = $cat->get_category_by_id($post_cat);

        $c_like = $react->get_num_like($post_id,0);

        $c_rate1 = $react->get_num_rate($post_id,1);

        $c_rate2 = $react->get_num_rate($post_id,2);

        $c_rate3 = $react->get_num_rate($post_id,3);

        $c_rate4 = $react->get_num_rate($post_id,4);

        $c_rate5 = $react->get_num_rate($post_id,5);

        $row_user = $user->get_user_by_id($user_id);

        $user_name = $row_user['user_name'];
        $user_image = $row_user['user_image'];

        $view->post_detail($post_id,$user_id,$user_name,$user_image,$post_date,$cat_name,$content,$c_rate5,$c_rate4,$c_rate3,$c_rate2,$c_rate1,$c_like);

        $this->get_answers();

        $this->answers();
    }

    public function answers()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');

        $view = $this->require_view('postView');
        
        $get_id = $_GET['post_id'];
        
        $run_posts = $post->get_post_by_id($get_id,0);
        foreach ($run_posts as $row_posts) {
            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
        }

        $view->answers($post_id);

        $user_ans = $_SESSION['user_email'];
        $row_ans = $user->get_user($user_ans);

        $user_ans_id = $row_ans['user_id'];
        $user_ans_name = $row_ans['user_name'];


        if (isset($_POST['reply'])) {
            $answers = htmlentities($_POST['answers']);
            $check_content = $post->check_content($answers);

            $data_ans = array(
                'content' => $answers,
                'post_id' => $post_id,
                'user_id' => $user_id,
                'user_ans' => $user_ans_name
            );

            $insert_ans = $post->insert_new_ans($data_ans);
            
            $up_val = array(
                'num_ans=num_ans+1'
            );

            $up_cond = array(
                "user_id='$user_ans_id'"
            );

            $update_ans = $user->update_num_post_ans($up_val,$up_cond);

            $num_ans_rank = $user->get_ranking($user_ans_id);

            if($num_ans_rank == 0){

                $data_rank = array(
                    'user_id' => $user_ans_id, 
                    'scores' => 2, 
                    'numpost_thismonth' => 0, 
                    'numans_thismonth' => 1
                );

                $insert_rank = $user->insert_ranking($data_rank);
            }else if($num_ans_rank != 0){

                $up_rank_val = array(
                    'numans_thismonth = numans_thismonth +1', 
                    'scores = scores+2'
                );

                $up_rank_cond = array(
                    "user_id = '$user_ans_id'",
                    "month = month(NOW())",
                    "year = year(NOW())"
                );

                $update_rank = $user->update_ranking($up_rank_val,$up_rank_cond);
            }

            echo "<script>alert('Success!')</script>";
            echo "<script>window.open('?controller=postController&action=post_detail&post_id=$post_id','_self')</script>";
        }
    }

    public function get_answers()
    {
        
        $post = $this->require_model('post');
        $react = $this->require_model('react');

        $get_id = $_GET['post_id'];
        
        $run_ans = $post->get_ans_by_id($get_id,0);

        if($run_ans != NULL){

            foreach ($run_ans as $row) {
                $ans = $post->convert_clickable_links($row['content']);
                $ans_name = $row['user_ans'];
                $ans_date = $row['ans_date'];
                $ans_id = $row['ans_id'];

                $c_like = $react->get_num_like($ans_id,1);

                echo "
                <div class='row'>
                    <div class='col-md-6 col-md-offset-3'>
                        <div class='panel panel-info' style='border: 1px solid blue; border-radius: 10px;'>
                            <div class='panel-body'>
                                <div>
                                    <h5><strong>$ans_name</strong><i> answered</i> on $ans_date</h5>
                                    <p class='text' style='margin-left:5px;font-size:17px;'>$ans</p>
                                    <a href='?controller=postController&action=like_ans&ans_id=$ans_id' style='float:right;'>
                                        <button class='btn btn-outline-primary'>Like($c_like)</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                ";
            }
        }
    }

    public function report()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $cat = $this->require_model('category');

        $view = $this->require_view('postView');

        $get_id = $_GET['post_id'];
        
        $run_posts = $post->get_post_by_id($get_id,0);
        foreach ($run_posts as $row_posts) {

            $post_id = $row_posts['post_id'];
            $user_id = $row_posts['author'];
            $content = $post->convert_clickable_links($row_posts['content']);
            $post_cat = $row_posts['post_cat'];
            $post_date = $row_posts['post_date'];

            $cat_name = $cat->get_category_by_id($post_cat);
            
            $row_user = $user->get_user_by_id($user_id);

            $user_name = $row_user['user_name'];
            $user_image = $row_user['user_image'];

            $user_rp = $_SESSION['user_email'];
            
            $row_rp = $user->get_user($user_rp);
            
            $user_rp_id = $row_rp['user_id'];

            $view->report_post($user_image,$user_id,$user_name,$post_date,$cat_name,$content);

            if (isset($_POST['report'])) {
                $report_reasons = htmlentities($_POST['rpreasons']);
                $check_report_content = $post->check_content($report_reasons);

                $data_rp = array(
                    'post_id' => $post_id,
                    'user_id' => $user_id,
                    'reason' => $report_reasons
                );

                $insert = $post->insert_report($data_rp);

                echo "<script>alert('Thank you for reporting! We will review and remove this post if it violates community standards.')</script>";
                echo "<script>window.open('?controller=postController&action=post_detail&post_id=$post_id','_self')</script>";
            }
        }   
    }

    public function like()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $react = $this->require_model('react');

        $post_id = $_REQUEST['post_id'];

        $user_like = $_SESSION['user_email'];

        $row_ulike = $user->get_user($user_like);
        $user_like_id = $row_ulike['user_id'];

        $row_like = $react->get_user_like($user_like_id,$post_id,0);

        if($row_like!=0){
            $data_like = array(
                "post_id='$post_id'",
                "user_like = '$user_like_id'"
            );

            $del_postlike = $react->delete_like($data_like,0);
        }
        else{
            $data_like = array(
                'user_like' => $user_like_id,
                'post_id' => $post_id
            );

            $insertPostlike = $react->insert_react($data_like,0);
        }
        header("location: ?controller=postController&action=post_detail&post_id=$post_id");
    }

    public function like_ans()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $react = $this->require_model('react');

        $ans_id = $_REQUEST['ans_id'];

        $user_like = $_SESSION['user_email'];

        $row_ulike = $user->get_user($user_like);
        $user_like_id = $row_ulike['user_id'];

        $rw_posts = $post->get_ans_by_id($ans_id,1);
        foreach ($rw_posts as $row_posts) {
             $post_id = $row_posts['post_id'];
        }

        $row_like = $react->get_user_like($user_like_id,$ans_id,1);

        if($row_like!=0){
            $data_like = array(
                "ans_id='$ans_id'",
                "user_like = '$user_like_id'"
            );

            $del_anslike = $react->delete_like($data_like,1);
        }
        else{
            $data_like = array(
                'user_like' => $user_like_id,
                'ans_id' => $ans_id
            );

            $insert_anslike = $react->insert_react($data_like,1);
        }
        header("location: ?controller=postController&action=post_detail&post_id=$post_id");
    }

    public function rate()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $react = $this->require_model('react');

        $post_id = $_REQUEST['post_id'];
        $rate = $_POST['rateval'];
        
        $row_urate = $user->get_user($user_rate);
        $user_rate_id = $row_urate['user_id'];

        $row_rate = $react->get_user_rate($user_rate_id,$post_id);

        if($row_rate!=0){
            $up_rate_val = array(
                'rate = $rate'
            );

            $up_rate_cond = array(
                "post_id = '$post_id'",
                "user_rate = '$user_rate_id'"
            );

            $update_postrate = $react->update_rate($up_rate_val,$up_rate_cond);
        }
        else{
            $data_rate = array(
                'user_rate' => $user_rate_id,
                'rate' => $rate,
                'post_id' => $post_id
            );

            $insert_postrate = $react->insert_react($data_rate,2);
        }
        header("location: ?controller=postController&action=post_detail&post_id=$post_id");
    }

    // public function my_posts()
    // {
    //     $user = $this->require_model('user');
    //     $post = $this->require_model('post');
    //     $cat = $this->require_model('category');
        
    //     $view = $this->require_view('postView');
    //     $my_posts = $view->my_posts();
        
    //     $u_id = $_GET['u_id'];

    //     $run_posts = $post->get_post_by_id($u_id,1);

    //     if($run_posts != NULL){
    //         foreach ($run_posts as $row_posts) {
                
    //             $post_id = $row_posts['post_id'];
    //             $user_id = $row_posts['author'];
    //             $content = $post->convert_clickable_links($row_posts['content']);
    //             $post_cat = $row_posts['post_cat'];
    //             $post_date = $row_posts['post_date'];

    //             $cat_name = $cat->get_category_by_id($post_cat);
                        
    //             $row_user = $user->get_user_by_id($user_id);

    //             $user_name = $row_user['user_name'];
    //             $user_image = $row_user['user_image'];

    //             $user_email = $_SESSION['user_email'];
    //             $row = $user->get_user($user_email);
            
    //             $user_id = $row['user_id'];
    //             $u_email = $row['user_email'];

    //             $rateavg = $post->get_rate_avg($post_id);

    //             $rateavg_sub = $post->get_rate_avg_sub($rateavg);

    //             if(strlen($content) >= 1){
    //                 $post_view = $view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);
    //             }
    //         }
    //     }
    // }

    public function edit_post()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $cat = $this->require_model('category');
        
        if(isset($_GET['post_id'])){
            $get_id = $_GET['post_id'];
            $run = $post->get_post_by_id($get_id,0);

            foreach ($run as $row) {
                $content = $row['content'];
                $user_id = $row['author'];
                $post_cat = $row['post_cat'];
            }
        }

        $cats = $cat->get_category();
        $post_cat_name = $cat->get_category_by_id($post_cat);

        $view = $this->require_view('postView');
        $view->edit_post($post,$content,$cats,$post_cat,$post_cat_name);

        if(isset($_POST['update'])){
            $new_content = $_POST['new_content'];
            $new_post_cat = $_POST['cat_id'];

            $message = strip_tags(trim($new_content));
            //get hashtag from message
            $hashtag = $this->gethashtags($message);

            $up_post_val = array(
                "content='$new_content'",
                "post_cat = '$new_post_cat'",
                "hashtag = '$hashtag'"
            );

            $up_post_cond = array(
                "post_id='$get_id'"
            );

            $update_post = $post->update_post($up_post_val,$up_post_cond);

            if($update_post){
                echo"<script>alert('Post has been updated!')</script>";
            }else{
                echo"<script>alert('Erorr! Please try again.')</script>";
            }
            echo"<script>window.open('?controller=userController&action=profile&u_id=$user_id','_self')</script>";
        }
    }

    public function delete_post()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        
        if(isset($_GET['post_id'])){
            $post_id = $_GET['post_id'];

            $run_post = $post->get_post_by_id($post_id,0);

            foreach ($run_post as $row_post) {
                $user_id = $row_post['author'];
            }
            
            $up_numpost_val = array(
                'num_post = num_post-1'
            );

            $up_numpost_cond = array(
                "user_id='$user_id'"
            );

            $update_post = $user->update_user_account($up_numpost_val,$up_numpost_cond);

            $up_rankpost_val = array(
                'numpost_thismonth = numpost_thismonth - 1',
                'scores = scores-5'
            );

            $up_rankpost_cond = array(
                "user_id='$user_id'",
                "month = month(NOW())",
                "year = year(NOW())"
            );

            $update_rank_post = $user->update_ranking($up_rankpost_val,$up_rankpost_cond);

            $run_user = $user->get_user_ans_of_post($post_id);

            if($run_user != NULL){
                foreach ($run_user as $row_user) {
                    
                    $user_ans_name = $row_user['user_ans'];
                    $user_ans_id = $row_user['user_id'];
                    $ans_id = $row_user['ans_id'];

                    $row_ans = $post->get_num_ans_of_post($post_id,$user_ans_name);
                    $ans = intval($row_ans);

                    $up_numans_val = array(
                        "num_ans = num_ans-'$ans'"
                    );

                    $up_numans_cond = array(
                        "user_name='$user_ans_name'"
                    );                    

                    $update_ans = $user->update_user_account($up_numans_val,$up_numans_cond);
                    
                    $up_rankans_val = array(
                        "numans_thismonth = numans_thismonth - '$ans'",
                        "scores = scores-(2*'$ans')"
                    );

                    $up_rankans_cond = array(
                        "user_id='$user_id'",
                        "month = month(NOW())",
                        "year = year(NOW())"
                    );

                    $update_arank = $user->update_ranking($up_rankans_val,$up_rankans_cond);
                    
                    $del_anslike_table = "ans_like";

                    $del_anslike_cond = array(
                        "ans_id='$ans_id'"
                    );
                    $delete_ans_like = $post->delete($del_anslike_table,$del_anslike_cond);
                    
                }
            }

            $del_post_table = 'post';

            $del_post_cond = array(
                "post_id='$post_id'"
            );
            $delete_post = $post->delete($del_post_table,$del_post_cond);


            $del_postlike_table = 'post_like';
            $delete_post_like = $post->delete($del_postlike_table,$del_post_cond);

            $del_postrate_table = 'post_rate';
            $delete_post_rate = $post->delete($del_postrate_table,$del_post_cond);

            $del_answer_table = 'answers';
            $delete_post_answer = $post->delete($del_answer_table,$del_post_cond);

            if($delete_post){
                echo"<script>alert('Post has been deleted!')</script>";
            }else{
                echo"<script>alert('Erorr! Can not delete post!')</script>";
            }
            echo"<script>window.open('?controller=userController&action=profile&u_id=&user_id','_self')</script>";
        }
    }

    public function search_post()
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $cat = $this->require_model('category');

        $view = $this->require_view('postView');
        $search_view = $view->search_post();

        if (isset($_GET['search'])) 
        {
            $search_query = htmlentities($_GET['user_query']);  
        }

        if($search_query != NULL){

            $run_posts = $post->get_post_search($search_query);

            if($run_posts != NULL){

                foreach ($run_posts as $row_posts) {
                    $post_id = $row_posts['post_id'];
                    $user_id = $row_posts['author'];
                    $content = $post->convert_clickable_links($row_posts['content']);
                    $post_cat = $row_posts['post_cat'];
                    $post_date = $row_posts['post_date'];

                    $cat_name = $cat->get_category_by_id($post_cat);

                    $row_user = $user->get_user_by_id($user_id);

                    $user_name = $row_user['user_name'];
                    $f_name = $row_user['f_name'];
                    $l_name = $row_user['l_name'];
                    $user_image = $row_user['user_image'];

                    $rateavg = $post->get_rate_avg($post_id);

                    $rateavg_sub = $post->get_rate_avg_sub($rateavg);

                    $post_view = $view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);
                }
            }else{
                echo '<hr><center><h3>There is no post like <strong><i>'.$search_query.'</i></strong></h3></center>';
            }
        }
    }

    public function search_hashtag() 
    {
        $user = $this->require_model('user');
        $post = $this->require_model('post');
        $cat = $this->require_model('category');

        $view = $this->require_view('postView');
        

        if(isset($_GET['hashtag'])) {
            $tags = ($_GET['hashtag']);
            $get_post_hash = $post->get_post_by_hashtag($tags);
        }

        $tag_view = $view->search_hashtag($tags);

        if($get_post_hash != NULL){
            foreach ($get_post_hash as $row_posts) {

                $post_id = $row_posts['post_id'];
                $user_id = $row_posts['author'];
                $content = $post->convert_clickable_links($row_posts['content']);
                $post_cat = $row_posts['post_cat'];
                $post_date = $row_posts['post_date'];
                $hashtag = $row_posts['hashtag'];

                $cat_name = $cat->get_category_by_id($post_cat);

                $row_user = $user->get_user_by_id($user_id);

                $user_name = $row_user['user_name'];
                $f_name = $row_user['f_name'];
                $l_name = $row_user['l_name'];
                $user_image = $row_user['user_image'];

                $rateavg = $post->get_rate_avg($post_id);

                $rateavg_sub = $post->get_rate_avg_sub($rateavg);

                $post_view = $view->get_posts($user_id,$user_image,$user_name,$post_date,$cat_name,$content,$rateavg_sub,$post_id);

            }
        }
    }

    public function gethashtags($message)
    {
        //Match the hashtags
        preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $message, $matchedHashtags);
        $hashtag = '';
        // For each hashtag, strip all characters but alpha numeric
        if(!empty($matchedHashtags[0])) {
            foreach($matchedHashtags[0] as $match) {
                $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
            }
        }
        //to remove last comma in a string
        return rtrim($hashtag, ',');
    }


}
?>