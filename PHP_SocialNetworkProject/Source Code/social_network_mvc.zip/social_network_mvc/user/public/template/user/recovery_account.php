<!DOCTYPE html>
<?php

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}
?>
<html>
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Fogotten Password</h4>
			</div>
			<div class="modal-body">
				<form action="" method="post" id="f">
					<strong>What is the name of the town where you were born?</strong>

					<textarea class="form-control" cols="83" rows="4" name="r_content" placeholder="Type your answer..."></textarea><br>

					<input class="btn btn-default" type="submit" name="sub" value="Submit" style="width: 100px; float: right;"><br><br><br>

					<pre>Answer the above question.<br>If you forgot your password we will ask you this question.</pre><br>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
</html>