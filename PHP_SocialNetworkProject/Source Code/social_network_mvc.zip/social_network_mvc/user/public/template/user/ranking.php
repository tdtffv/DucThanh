<!DOCTYPE html>
<?php
require_once('public/template/main/header.php');

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}
?>
<html>
<head>
	<title>Raking</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta http-equiv="refresh" content="15;url=http://localhost/social_network_mvc/user/?controller=userController&action=ranking">
	<link rel="stylesheet" type="text/css" href="public/css/ranking.css">
</head>
<body>
<div class="row">
	<div class="col-sm-2"></div>
	<div class="col-sm-8">
		<form action="" method="post" enctype="multipart/form-data">
			<table class="table table-bordered table-hover">
				<tr align="center">
					<td colspan="6" class="active"><h2>Ranking <strong><?php echo date("F Y");?></strong></h2></td>
				</tr>
				<tr>
					<th id="rank-title"><center>No.</center></th>
					<th id="rank-title"><center>Member</center></th>
					<th id="rank-title"><center>Scores</center></th>
					<th id="rank-title"><center>Title</center></th>
				</tr>
	        	
			<!-- </table>
		</form>
	</div>
	<div class="col-sm-2"></div>
</div>
</body>
</html> -->