<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign In</title>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/login.css">
</head>
<body>
<div class="row">
	<div class="col-sm-12">
		<div class="well">
			<center><h1 style="color: white;">UDPT-16</h1></center>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="main-content">
			<div class="header">
				<h3 style="text-align: center;"><strong>Login</strong></h3><br>
			</div>
			<div class="l-part">
				<form method="post" action="?controller=userController&action=login">
					<input type="email" name="email" placeholder="Email" required="required" class="form-control input-md"><br>
					<div class="overlap-text">
						<input type="password" name="pass" placeholder="Password" required="required" class="form-control input-md"/><br>			
					</div>
					<a id="fg_pass" data-toggle="tooltip" title="Reset Password" href="?controller=userController&action=forgot_password">Forgot Password?</a>
					<a id="d_have_acc" title="Create Account!" href="?controller=userController&action=signup_view">Don't have an account?</a><br><br>
					<center>
						<button id="signin" class="btn btn-info btn-lg" name="login">Login</button>
					</center>
				</form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function changeCaptcha(obj){
    var n = Math.random();
    obj.setAttribute('src','captcha/captcha.php?n='+n);
}
</script>
</body>
</html>