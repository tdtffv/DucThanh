<!DOCTYPE html>
<?php

require_once('public/template/main/header.php');

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}

?>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo "$first_name $last_name"; ?> Profile</title>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/profile.css">
</head>
<body>
<div class="row">
	<div class="col-sm-2">	
	</div>
	<div class="col-sm-8">
		<div>
			<div><img id='cover-img' class='img-rounded' src='public/images/cover/<?php echo $user_cover;?>' alt='cover'></div>
		</div>
		<div id='profile-img'>
			<img src='public/images/user/<?php echo $user_image;?>' alt='Profile' class='img-circle' width='180px' height='185px'>
		</div><br>
	</div>
	<div class="col-sm-2">
	</div>
</div>
<div class="row">
	<div class="col-sm-2">
	</div>
	<div class="col-sm-2" style="background-color: lavender;text-align: center;left: 0.9%;border-radius: 5px;">
		<center><h2><strong>About</strong></h2></center>
		<center><h4><strong><?php echo "$first_name $last_name";?></strong></h4></center>
		<p><strong><i style='color:grey;'><?php echo $describe_user;?></i></strong></p><br>
		<p><strong>Lives In: </strong><?php echo $user_country;?></p><br>
		<p><strong>Member Since: </strong><?php echo $register_date;?></p><br>
		<p><strong>Gender: </strong><?php echo $user_gender;?></p><br>
		<p><strong>Date of Birth: </strong><?php echo $user_birthday;?></p><br>
		<p><strong>Total posts: </strong><?php echo $num_post;?></p><br>
		<p><strong>Total answers: </strong><?php echo $num_ans;?></p><br>
	</div>
	<div class="col-sm-6">
<!-- 
	</div>
	<div class="col-sm-2"></div>
</div>
</body>
</html> -->