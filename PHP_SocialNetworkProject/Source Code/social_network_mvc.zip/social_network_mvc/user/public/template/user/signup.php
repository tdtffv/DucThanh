<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign Up</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/signup.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12">
			<div class="well">
				<center><h1 style="color: white;">UDPT-16</h1></center>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="main-content">
				<div class="header">
					<h3 style="text-align: center;"><strong>Join with us</strong></h3><hr>
				</div>
				<div class="l-part">
					<form method="post" action="?controller=userController&action=signup">
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-pencil"></i>
							</span>
							<input type="text" class="form-control" placeholder="First Name" name="first_name" required="required" autocomplete="off">
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-pencil"></i>
							</span>
							<input type="text" class="form-control" placeholder="Last Name" name="last_name" required="required" autocomplete="off">
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-lock"></i>
							</span>
							<input type="password" class="form-control" placeholder="Password" name="u_pass" required="required" autocomplete="off">
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-lock"></i>
							</span>
							<input type="password" class="form-control" placeholder="Confirm password" name="u_repass" required="required" autocomplete="off">
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-user"></i>
							</span>
							<input type="email" class="form-control" placeholder="Email" name="u_email" required="required" autocomplete="off">
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-chevron-down"></i>
							</span>
							<select class="form-control" name="u_country" required="required">
								<option>Vietnam</option>
								<option>United State of America</option>
								<option>Japan</option>
								<option>China</option>
							</select>
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-chevron-down"></i>
							</span>
							<select class="form-control input-md" name="u_gender" required="required">
								<option>Male</option>
								<option>Female</option>
								<option>Others</option>
							</select>
						</div><br>
						<div class="input-group">
							<span class="input-group-addon">
								<i class="glyphicon glyphicon-calendar"></i>
							</span>
							<input type="date" class="form-control input-md" placeholder="Birthday" name="u_birthday" required="required">
						</div><br>
						<a id="al_ac" data-toggle="tooltip" title="Signin" href="?controller=userController&action=login_view">Already have an account?</a><br><br>
						<center>
							<button id="signup" class="btn btn-info btn-lg" name="sign_up">Sign Up</button>
						</center>
					</form>
					<br>
					<center><h4>or</h4></center>
					<br>
					<form method="post" action="api/signup_gmail.php">
					<center>
						<button id="signup-by-mail" class="btn btn-info btn-lg" name="signup_mail" style="width: 60%;
	border-radius: 30px;
	background-color: white;
	border: none;
	color: plum;">Signup with Gmail</button>
					</center>
				</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>