<!DOCTYPE html>
<html>
<head>
	<title>Forgotten Password</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
	body{
		overflow-x: hidden;
	}
	.main-content{
		width: 50%;
		height: 40%;
		margin: 10px auto;
		background-color: white;
		padding: 40px 50px;
		border: 2px solid plum;
	}
	.header{
		margin-bottom: 5px;
	}
	.well{
		background-color: plum;
	}
	#signup{
		background-color: plum; 
		border: none;
		border-radius: 30px;
		width: 35%;
	}
</style>
<body>
<div class="row">
	<div class="col-sm-12">
		<div class="well">
			<center><h1 style="color: white;"><strong>UDPT-16</strong></h1></center>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="main-content">
			<div class="header">
				<h3 style="text-align: center;"><strong>Forgot Password</strong></h3><br><br>
			</div>
			<div class="l_pass">
				<form action="" method="post">
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<input id="email" class="form-control" type="email" name="email" placeholder="Enter your email" required>
					</div><br>
					<pre class="text">Answer the question:<br><strong>What is the name of the town where you were born?</strong></pre>
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
						<input id="mgs" class="form-control" type="text" name="recovery_account" placeholder="Type your answer..." autocomplete="off" required>
					</div><br>
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input id="password" class="form-control" type="password" name="pass" placeholder="Enter your new password" required>
					</div><br>
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
						<input id="password" class="form-control" type="password" name="repass" placeholder="Confirm your new password" required>
					</div><hr>
					<a href="?controller=userController&action=login_view" style="text-decoration: none; float: right; color: plum;" data-toggle="tooltip" title="Signin">Back to Login?</a><br><br>
					<center>
						<button id="signup" class="btn btn-info btn-lg" name="submit">Submit</button>
					</center>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>