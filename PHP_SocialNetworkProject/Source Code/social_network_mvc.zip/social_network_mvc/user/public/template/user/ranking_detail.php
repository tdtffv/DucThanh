<!DOCTYPE html>
<?php

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}
?>
<link rel="stylesheet" type="text/css" href="public/css/ranking_detail.css">
<!-- <html> -->
<tr>
	<td><center><?php echo "#".$rank; ?></center></td>
	<td>
		<div class='row'>
			<div class='col-sm-5'>
				<div class='row'>
					<div class='col-sm-4'>
						<a href='?controller=userController&action=user_profile&u_id=<?php echo $user_id;?>'>
							<img id="img" class="img-circle" src='public/images/user/<?php echo $user_image;?>' width=60px height=60px title='<?php echo $user_name;?>'/>
						</a>
					</div>
					<div class='col-sm-8'>
						<a id="user-rank" href='?controller=userController&action=user_profile&u_id=<?php echo $user_id;?>'>
							<strong><h4><?php echo $user_name;?></h4></strong>
						</a>
					</div>
				</div>
			</div>
		</div>
	</td>
	<td id="user-scores"><center><?php echo $scores; ?></center></td>
	<td><center><?php echo $title; ?></center></td>
</tr>

<!-- </table>
		</form>
	</div>
	<div class="col-sm-2"></div>
</div>
</body>
</html> -->