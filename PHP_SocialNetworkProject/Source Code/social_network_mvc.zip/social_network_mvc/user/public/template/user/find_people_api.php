<!DOCTYPE html>
<?php

require_once('public/template/main/header.php');

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}

$db = new user();
$data = $db->get_all_users();

?>
<html>
<head>
	<title>Find People</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/find_people.css">
</head>
<body>
<div class="row">
	<div class="col-sm-12">
		<center><h2>Find User</h2></center><br><br>
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
				
				<form action="" class="search_form" method="GET">
					<form action="?controller=userController&action=find_people_api" method="post">
						<input type="text" name="search_user" placeholder="Search user here..." id="search" oninput=search(this.value) autocomplete="off">
					</form>
					<ul id="dataViewer">
						<?php foreach ($data as $i) { ?>
						<li><?php echo $i['f_name'];?>&nbsp<?php echo $i['l_name']; ?></li>
					<?php } ?>
					</ul>
					<button id="search-btn" class="btn btn-info" type="submit" name="search_user_btn">Search</button>
					<input type="hidden" name="controller" value="userController">
					<input type="hidden" name="action" value="find_people">
				</form>

				<script src="public/js/search.js"></script>
			</div>
			<div class="col-sm-4"></div>
		</div><br><br>
	</div>
</div>
</body>
</html>