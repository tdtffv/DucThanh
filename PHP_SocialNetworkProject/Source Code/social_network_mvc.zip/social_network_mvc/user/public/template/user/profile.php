<!DOCTYPE html>
<?php

require_once('public/template/main/header.php');

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}

?>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo "$first_name $last_name"; ?></title>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/profile.css">
</head>
<body>
<div class="row">
	<div class="col-sm-2">	
	</div>
	<div class="col-sm-8">
		<div>
			<div><img id='cover-img' class='img-rounded' src='public/images/cover/<?php echo $user_cover;?>' alt='cover'></div>
			<form action='?controller=userController&action=profile&u_id=<?php echo $user_id;?>' method='post' enctype='multipart/form-data'>
			<ul class='nav pull-left' style='position:absolute;top:10px;left:40px;'>
				<li class='dropdown'>
					<button class='dropdown-toggle btn btn-default' data-toggle='dropdown'>Change Cover</button>
					<div class='dropdown-menu'>
						<center>
						<label class='btn btn-info'>Select Cover<input type='file' name='u_cover' size='60' style= 'width: 0;overflow: hidden;opacity:0;filter:alpha(opacity=0);display: inline;position: absolute;'/></label><br><br>
						<button name='updatecover' class='btn btn-info'>Update Cover</button>
						</center>
					</div>
				</li>
			</ul>
			</form>
		</div>
		<div id='profile-img'>
			<img src='public/images/user/<?php echo $user_image;?>' alt='Profile' class='img-circle' width='180px' height='185px'>
			<form action='?controller=userController&action=profile&u_id=<?php echo $user_id;?>' method='post' enctype='multipart/form-data'>
			<label id='update_profile'> Select Avatar <input type='file' name='u_image' size='60' style= 'width: 0;overflow: hidden;opacity:0;filter:alpha(opacity=0);display: inline;position: absolute;'/></label><br><br><br>
			<button id='button_profile' name='updateavatar' class='btn btn-info'>Update Avatar</button>
			</form>
		</div><br>
	</div>
	<div class="col-sm-2">
	</div>
</div>
<div class="row">
	<div class="col-sm-2">
	</div>
	<div class="col-sm-2" style="background-color: lavender;text-align: center;left: 0.9%;border-radius: 5px;">
		<center><h2><strong>About</strong></h2></center>
		<center><h4><strong><?php echo "$first_name $last_name";?></strong></h4></center>
		<p><strong><i style='color:grey;'><?php echo $describe_user;?></i></strong></p><br>
		<p><strong>Lives In: </strong><?php echo $user_country;?></p><br>
		<p><strong>Member Since: </strong><?php echo $register_date;?></p><br>
		<p><strong>Gender: </strong><?php echo $user_gender;?></p><br>
		<p><strong>Date of Birth: </strong><?php echo $user_birthday;?></p><br>
		<p><strong>Total posts: </strong><?php echo $num_post;?></p><br>
		<p><strong>Total answers: </strong><?php echo $num_ans;?></p><br>
		<a href='?controller=userController&action=edit_account_prepare&u_id=<?php echo $user_id; ?>' class='btn btn-info' id='edit-btn' style='background-color: plum;border: 1px solid plum;' />Edit Profile</a><br><br>
	</div>
	<div class="col-sm-6">
<!-- 
	</div>
	<div class="col-sm-2"></div>
</div>
</body>
</html> -->