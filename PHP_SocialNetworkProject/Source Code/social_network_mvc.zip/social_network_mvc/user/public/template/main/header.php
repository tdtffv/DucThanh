<link rel="stylesheet" type="text/css" href="public/css/header.css">
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" aria-expanded="false">
			<span class="sr-only"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			<a id="logo" class="navbar-brand" href="?controller=homeController&action=home">UDPT-16</a>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">

			<li><a href="?controller=homeController&action=home">Home</a></li>
	        <li><a href="?controller=userController&action=profile">Profile</a></li></li>
			<li><a href="?controller=userController&action=find_people">Find People</a></li>
			<li><a href="?controller=userController&action=messages&u_id=new">Message</a></li>
			<li><a href="app/chatbot/chatbot.php">Chatbot</a></li>
			<li><a href="?controller=userController&action=ranking">Ranking</a></li>

			<li class='dropdown'>
					<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span><i class='glyphicon glyphicon-chevron-down'></i></span></a>
					<ul class='dropdown-menu'>
						<li>
							<a href='?controller=userController&action=logout'>Logout</a>
						</li>
					</ul>
				</li>

			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
					<form class="navbar-form navbar-left" method="get" action="">
						<div class="form-group">
							<input id="user-query" type="text" class="form-control" name="user_query" placeholder="Search..." autocomplete="off">
						</div>
						<button id="search_btn" type="submit" class="btn btn-info" name="search">Search</button>
						<input type="hidden" name="controller" value="postController">
						<input type="hidden" name="action" value="search_post">
					</form>
				</li>
			</ul>
		</div>
	</div>
</nav>