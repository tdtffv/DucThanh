<link rel="stylesheet" type="text/css" href="public/css/get_posts.css">
<div class='row'>
    <div class='col-sm-3'></div>
    <div id='posts' class='col-sm-6'>
        <div class='row'>
            <div class='col-sm-2'>
            <p><img src='public/images/user/<?php echo $user_image;?>' class='img-circle' width='80px' height='80px'></p>
            </div>
            <div class='col-sm-6'>
                <h3><a id='user_name' href='?controller=userController&action=find_user_profile&u_id=<?php echo $user_id;?>'><?php echo $user_name;?></a></h3>
                <h4><small id='up_post'>Updated a post on <strong><?php echo $post_date;?></strong></small></h4>
            </div>
            <div class='col-sm-4'>
                <h4 id="cat"><strong><?php echo $cat_name;?></strong></h4>
            </div>
        </div>
        <div class='row'>
            <div class='col-sm-12'>
                <h3><p><?php echo $content;?></p></h3>
            </div>
        </div><br>
        <h5>Avergare Rate: <strong id="rate-avg"><?php echo $rateavg_sub;?></strong></h5>
        <a href='?controller=postController&action=report&post_id=<?php echo $post_id;?>' id="btn">
            <button class='btn btn-danger'>Report</button>
        </a>
        <a href='?controller=postController&action=post_detail&post_id=<?php echo $post_id;?>' id="btn">
            <button class='btn btn-info'>View</button>
        </a>
    </div>
    <div class='col-sm-3'></div>
</div><br><br>