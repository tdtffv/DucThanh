<link rel="stylesheet" type="text/css" href="public/css/answers.css">

<div class='row'>
    <div class='col-md-6 col-md-offset-3'>
        <div class='panel panel-info'>
            <div class='panel-body'>
                <form action='' method='post' class='form-inline'>
                    <textarea id='cont' placeholder = 'Write your answer here...' class='pb-cmnt-textarea' name='answers'></textarea>
                    <button class='btn btn-info pull-right' name='reply'>Answer</button>
                </form>
            </div>
        </div>
    </div>
</div>