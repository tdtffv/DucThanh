
<div id='own_posts'>
	<div class='row'>
		<div id='posts' class='col-sm-12'>
			<div class='row'>
				<div class='col-sm-10'>
				<p><img src='public/images/user/<?php echo $user_image;?>' class='img-circle' width='80px' height='80px'></p>
				</div>
				<div class='col-sm-6'>
					<h3><a style='text-decoration:none; cursor:pointer; color #3897f0;' href='?controller=userController&action=profile&u_id=<?php echo $user_id;?>'><?php echo $user_name;?></a></h3>
					<h4><small style='color:black;'>Updated a post on <strong><?php echo $post_date;?></strong></small></h4>
				</div>
				<div class='col-sm-4'>
					<h4 style='color: black; float: right; color: grey;'><strong><?php echo $cat_name;?></strong></h4>
				</div>
			</div>
			<div class='row'>
				<div class='col-sm-2'></div>
				<div class='col-sm-8'>
					<h3><p><?php echo $content;?></p></h3>
				</div>
			</div>
			<a href='?controller=postController&action=delete_post&post_id=<?php echo $post_id;?>' style='float:right;'>
				<button class='btn btn-danger'>Delete</button>
			</a>
			<a href='?controller=postController&action=edit_post&post_id=<?php echo $post_id;?>' style='float:right;'>
				<button class='btn btn-info'>Edit</button>
			</a>
			<a href='?controller=postController&action=post_detail&post_id=<?php echo $post_id;?>' style='float:right;'>
				<button class='btn btn-outline-info'>View</button>
			</a>
			</div>
		</div><br><br>