<!DOCTYPE html>
<?php
	require_once('public/template/main/header.php');

	if(!isset($_SESSION['user_email'])){
		header("location: http://localhost/social_network_mvc/");
	}
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Report Post</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/report.css">
</head>
<body>
	<div class="row">
		<div class="col-sm-12">
			<div class='row'>
                <div class='col-sm-3'></div>
                <div id='posts' class='col-sm-6'>
                    <div class='row'>
                        <div class='col-sm-2'>
                        <p><img src='public/images/user/<?php echo $user_image;?>' class='img-circle' width='80px' height='80px'></p>
                        </div>
                        <div class='col-sm-6'>
                            <h3><a id="user-name" href='?controller=userController&action=profile&u_id=<?php echo $user_id;?>'><?php echo $user_name;?></a></h3>
                            <h4><small id='post-date'>Updated a post on <strong><?php echo $post_date;?></strong></small></h4>
                        </div>
                        <div class='col-sm-4'>
                            <h4 id="cat_id"><strong><?php echo $cat_name;?></strong></h4>
                        </div>
                    </div>
                    <div class='row'>
                        <div class='col-sm-12'>
                            <h3><p><?php echo $content;?></p></h3>
                        </div>
                    </div><br>
                </div>
                <div class='col-sm-3'></div>
                <div class='row'>
	                <div class='col-md-6 col-md-offset-3'>
	                    <div class='panel panel-info'>
	                        <div class='panel-body'>
	                            <form action='' method='post' class='form-inline'>
	                                <textarea id="rp-text" class='pb-cmnt-textarea' name='rpreasons' placeholder = 'Write your report reasons here.
Ex: Having words that violate community standards, Bad content, Spam,...'></textarea>
	                                <button class='btn btn-danger pull-right' name='report'>Report</button>
	                            </form>
	                        </div>
	                    </div>
	                </div>
	            </div>
            </div>
            </div><br><br>
		</div>
	</div>
</body>
</html>