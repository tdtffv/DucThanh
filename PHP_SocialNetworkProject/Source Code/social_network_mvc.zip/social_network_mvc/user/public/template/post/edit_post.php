<!DOCTYPE html>
<?php

require_once('public/template/main/header.php');

if(!isset($_SESSION['user_email'])){
	header("location: http://localhost/social_network_mvc/");
}
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Edit Post</title>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="public/css/edit_post.css">
</head>
<body>
<div class="row">
	<div class="col-sm-3"></div>
	<div class="col-sm-6">
		<form action="" method="post" id="f">
			<center><h2>Edit Your Post</h2></center><hr>
			<textarea id="content" class="form-control" cols="83" rows="4" name="new_content"><?php echo $content;?></textarea><br>
			<select name="cat_id" id="cat_id" class="form-control">
				<option value="<?php echo $post_cat; ?>"><?php echo $post_cat_name; ?></option>
				<?php
					foreach($cats as $cat):
				?>
					<option value="<?php echo $cat['cat_id'] ?>"><?php echo $cat['cat_name'] ?></option>
				<?php
					endforeach;
				?>
			</select><br>
			<input id="update-btn" type="submit" name="update" value="Update Post" class="btn btn-info"/>
		</form>
	</div>
	<div class="col-sm-3"></div>
</div>
</body>
</html>